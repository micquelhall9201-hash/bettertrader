import { useEffect, useRef } from 'react';

export interface Marker {
  tick: number;
  price: number;
  kind: 'long' | 'short' | 'exit' | 'liq' | 'ghost';
  label: string;
}

export interface Level {
  price: number;
  kind: 'entry' | 'liq';
  label: string;
}

interface Props {
  prices: number[];
  truePrices?: number[] | null;
  totalTicks: number;
  secondsPerTick: number;
  headProgress: number;
  live: boolean;
  markers: Marker[];
  levels?: Level[];
  height?: number;
  tone?: 'neutral' | 'up' | 'down';
}

const INK = '#f4efe4';
const MUTED = '#a7b0a8';
const GRID = 'rgba(244, 239, 228, 0.08)';
const UP = '#3fd98f';
const DOWN = '#ff4d4d';
const TRUE = '#5b8cff';
const GHOST = '#c084fc';
const BRAND = '#e8b64c';

export default function Chart(props: Props) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (canvas) {
      draw(canvas, props);
    }
  });
  return <canvas ref={ref} className="block w-full" style={{ height: (props.height ?? 320) + 'px' }} aria-label="Price chart" />;
}

function draw(canvas: HTMLCanvasElement, cfg: Props): void {
  const dpr = window.devicePixelRatio || 1;
  const cssW = canvas.clientWidth || 600;
  const cssH = canvas.clientHeight || 320;
  const wantW = Math.round(cssW * dpr);
  const wantH = Math.round(cssH * dpr);
  if (canvas.width !== wantW || canvas.height !== wantH) {
    canvas.width = wantW;
    canvas.height = wantH;
  }
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    return;
  }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, cssW, cssH);

  const padL = 8;
  const padR = 54;
  const padT = 14;
  const padB = 22;
  const plotW = cssW - padL - padR;
  const plotH = cssH - padT - padB;
  const pts = cfg.prices;
  const n = pts.length;

  // Autoscale: the visible window follows the data so every move looks big.
  let lo = 100;
  let hi = 0;
  const all = [...pts, ...(cfg.truePrices ?? [])];
  for (const lv of cfg.levels ?? []) {
    all.push(lv.price);
  }
  for (const m of cfg.markers) {
    all.push(m.price);
  }
  for (const p of all) {
    if (p < lo) lo = p;
    if (p > hi) hi = p;
  }
  if (n === 0) {
    lo = 30;
    hi = 70;
  }
  let span = Math.max(hi - lo, 6);
  const pad = span * 0.18;
  lo = Math.max(0, lo - pad);
  hi = Math.min(100, hi + pad);
  span = hi - lo;

  // Visible x-window: show whole round span so the right edge is the end.
  const lastTick = Math.max(1, cfg.totalTicks - 1);
  const xAt = (tick: number): number => padL + (tick / lastTick) * plotW;
  const yAt = (p: number): number => padT + (1 - (p - lo) / span) * plotH;

  // Grid + price axis on the right.
  ctx.font = '700 11px Manrope, ui-sans-serif, system-ui, sans-serif';
  const step = niceStep(span);
  for (let g = Math.ceil(lo / step) * step; g <= hi + 1e-9; g += step) {
    const y = yAt(g);
    ctx.beginPath();
    ctx.moveTo(padL, y);
    ctx.lineTo(padL + plotW, y);
    ctx.strokeStyle = GRID;
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = MUTED;
    ctx.textAlign = 'left';
    ctx.fillText(g.toFixed(step < 1 ? 1 : 0), padL + plotW + 8, y + 4);
  }
  const labelEvery = Math.max(1, Math.round(lastTick / 5));
  ctx.textAlign = 'center';
  for (let t = 0; t <= lastTick; t += labelEvery) {
    ctx.fillStyle = MUTED;
    ctx.fillText(fmtClock(t * cfg.secondsPerTick), xAt(t), cssH - 6);
  }

  if (n === 0) {
    ctx.fillStyle = MUTED;
    ctx.textAlign = 'center';
    ctx.font = '800 15px Manrope, ui-sans-serif, system-ui, sans-serif';
    ctx.fillText('Chart starts in a moment…', padL + plotW / 2, padT + plotH / 2);
    return;
  }

  // Levels: entry and liquidation lines.
  for (const lv of cfg.levels ?? []) {
    const y = yAt(lv.price);
    ctx.beginPath();
    ctx.moveTo(padL, y);
    ctx.lineTo(padL + plotW, y);
    ctx.strokeStyle = lv.kind === 'liq' ? DOWN : INK;
    ctx.setLineDash(lv.kind === 'liq' ? [6, 4] : [2, 4]);
    ctx.lineWidth = lv.kind === 'liq' ? 2 : 1.5;
    ctx.globalAlpha = 0.8;
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.globalAlpha = 1;
    ctx.font = '800 10px Manrope, ui-sans-serif, system-ui, sans-serif';
    ctx.fillStyle = lv.kind === 'liq' ? DOWN : INK;
    ctx.textAlign = 'left';
    ctx.fillText(lv.label, padL + 4, y - 4);
  }

  // True curve (reveal only).
  if (cfg.truePrices && cfg.truePrices.length > 1) {
    const ts = cfg.truePrices;
    ctx.beginPath();
    ctx.moveTo(xAt(0), yAt(ts[0]));
    for (let i = 1; i < ts.length; i++) {
      ctx.lineTo(xAt(i), yAt(ts[i]));
    }
    ctx.strokeStyle = TRUE;
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 5]);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // Head interpolation for smooth motion between ticks.
  const headIdx = n - 1;
  const prog = Math.max(0, Math.min(1, cfg.headProgress));
  let headX = xAt(0);
  let headY = yAt(pts[0]);
  if (n > 1) {
    const x0 = xAt(headIdx - 1);
    const y0 = yAt(pts[headIdx - 1]);
    const x1 = xAt(headIdx);
    const y1 = yAt(pts[headIdx]);
    headX = x0 + (x1 - x0) * prog;
    headY = y0 + (y1 - y0) * prog;
  }
  const lastFull = n === 1 ? 0 : headIdx - 1;

  // Smooth (bendy) path via quadratic midpoints.
  const trace = (): void => {
    ctx.beginPath();
    ctx.moveTo(xAt(0), yAt(pts[0]));
    for (let i = 1; i <= lastFull; i++) {
      const xPrev = xAt(i - 1);
      const yPrev = yAt(pts[i - 1]);
      const x = xAt(i);
      const y = yAt(pts[i]);
      const mx = (xPrev + x) / 2;
      const my = (yPrev + y) / 2;
      ctx.quadraticCurveTo(xPrev, yPrev, mx, my);
    }
    ctx.lineTo(headX, headY);
  };

  const lineColor = cfg.tone === 'up' ? UP : cfg.tone === 'down' ? DOWN : BRAND;
  const fillColor = cfg.tone === 'up' ? 'rgba(63, 217, 143, 0.22)' : cfg.tone === 'down' ? 'rgba(255, 77, 77, 0.2)' : 'rgba(232, 182, 76, 0.22)';

  trace();
  ctx.lineTo(headX, padT + plotH);
  ctx.lineTo(xAt(0), padT + plotH);
  ctx.closePath();
  const grad = ctx.createLinearGradient(0, padT, 0, padT + plotH);
  grad.addColorStop(0, fillColor);
  grad.addColorStop(1, 'rgba(5,6,4,0)');
  ctx.fillStyle = grad;
  ctx.fill();

  trace();
  ctx.shadowColor = lineColor;
  ctx.shadowBlur = 14;
  ctx.strokeStyle = lineColor;
  ctx.lineWidth = 3.5;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  ctx.stroke();
  ctx.shadowBlur = 0;

  if (cfg.live) {
    const pulse = 0.5 + 0.5 * Math.sin(performance.now() / 200);
    ctx.beginPath();
    ctx.arc(headX, headY, 8 + pulse * 5, 0, Math.PI * 2);
    ctx.fillStyle = cfg.tone === 'up' ? 'rgba(63,217,143,0.35)' : cfg.tone === 'down' ? 'rgba(255,77,77,0.35)' : 'rgba(255, 225, 77, 0.45)';
    ctx.fill();
    ctx.beginPath();
    ctx.arc(headX, headY, 5, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.fill();
    // Live price tag on the right axis.
    const price = pts[headIdx];
    const tagY = clamp(headY, padT + 9, padT + plotH - 9);
    ctx.fillStyle = BRAND;
    roundRect(ctx, padL + plotW + 3, tagY - 10, padR - 6, 20, 6);
    ctx.fill();
    ctx.fillStyle = '#6a4600';
    ctx.font = '900 11px Manrope, ui-sans-serif, system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(price.toFixed(1), padL + plotW + 3 + (padR - 6) / 2, tagY + 4);
  }

  ctx.font = '800 10px Manrope, ui-sans-serif, system-ui, sans-serif';
  cfg.markers.forEach((m, idx) => {
    const x = xAt(m.tick);
    const y = yAt(m.price);
    const color = m.kind === 'long' ? UP : m.kind === 'short' || m.kind === 'liq' ? DOWN : m.kind === 'ghost' ? GHOST : INK;
    ctx.beginPath();
    if (m.kind === 'liq') {
      ctx.moveTo(x, y - 8);
      ctx.lineTo(x + 7, y + 5);
      ctx.lineTo(x - 7, y + 5);
      ctx.closePath();
    } else {
      ctx.arc(x, y, 6, 0, Math.PI * 2);
    }
    ctx.fillStyle = color;
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#050604';
    ctx.stroke();
    const above = y > padT + plotH / 2;
    const ly = above ? y - 12 - (idx % 3) * 12 : y + 20 + (idx % 3) * 12;
    ctx.fillStyle = color;
    ctx.textAlign = x > padL + plotW - 50 ? 'right' : x < padL + 50 ? 'left' : 'center';
    ctx.fillText(m.label, x, ly);
  });
}

function niceStep(span: number): number {
  const raw = span / 4;
  const pow = Math.pow(10, Math.floor(Math.log10(raw)));
  const f = raw / pow;
  const m = f < 1.5 ? 1 : f < 3.5 ? 2 : f < 7.5 ? 5 : 10;
  return m * pow;
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number): void {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n));
}

function fmtClock(totalSeconds: number): string {
  const s = Math.max(0, Math.round(totalSeconds));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return m + ':' + (r < 10 ? '0' : '') + r;
}
