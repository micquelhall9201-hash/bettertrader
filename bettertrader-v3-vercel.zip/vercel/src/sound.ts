const KEY = 'bettertrader-muted';
let ctx: AudioContext | null = null;

export function isMuted(): boolean {
  try {
    return window.localStorage.getItem(KEY) === '1';
  } catch {
    return false;
  }
}

export function setMuted(m: boolean): void {
  try {
    window.localStorage.setItem(KEY, m ? '1' : '0');
  } catch {
    // ignore
  }
}

function ac(): AudioContext | null {
  if (isMuted()) {
    return null;
  }
  try {
    const W = window as unknown as { AudioContext?: typeof AudioContext; webkitAudioContext?: typeof AudioContext };
    const Ctor = W.AudioContext ?? W.webkitAudioContext;
    if (!Ctor) {
      return null;
    }
    if (!ctx) {
      ctx = new Ctor();
    }
    if (ctx.state === 'suspended') {
      void ctx.resume();
    }
    return ctx;
  } catch {
    return null;
  }
}

function tone(freq: number, dur: number, type: OscillatorType, gain: number, when = 0, slide?: number): void {
  const a = ac();
  if (!a) {
    return;
  }
  const o = a.createOscillator();
  const g = a.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, a.currentTime + when);
  if (slide !== undefined) {
    o.frequency.exponentialRampToValueAtTime(slide, a.currentTime + when + dur);
  }
  g.gain.setValueAtTime(0.0001, a.currentTime + when);
  g.gain.exponentialRampToValueAtTime(gain, a.currentTime + when + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, a.currentTime + when + dur);
  o.connect(g).connect(a.destination);
  o.start(a.currentTime + when);
  o.stop(a.currentTime + when + dur + 0.02);
}

export const sfx = {
  tick(): void {
    tone(880, 0.05, 'square', 0.04);
  },
  open(): void {
    tone(520, 0.08, 'triangle', 0.08);
    tone(780, 0.1, 'triangle', 0.08, 0.06);
  },
  cash(): void {
    tone(988, 0.08, 'triangle', 0.1);
    tone(1319, 0.14, 'triangle', 0.1, 0.07);
    tone(1760, 0.2, 'triangle', 0.08, 0.14);
  },
  loss(): void {
    tone(330, 0.16, 'sawtooth', 0.07, 0, 180);
  },
  liq(): void {
    tone(200, 0.35, 'sawtooth', 0.14, 0, 40);
    tone(90, 0.4, 'square', 0.1, 0.05, 30);
  },
  warn(): void {
    tone(1200, 0.06, 'square', 0.06);
    tone(1200, 0.06, 'square', 0.06, 0.12);
  },
  win(): void {
    [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.18, 'triangle', 0.09, i * 0.09));
  },
};
