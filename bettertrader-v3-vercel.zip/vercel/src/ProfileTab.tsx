import { useState } from 'react';
import { api } from './api';
import RoundPlay from './RoundPlay';
import { SPEED, errorMessage, fmtSigned, paceLabel, unwrap, type Pace, type Player, type RoundState } from './lib';

interface Props {
  player: Player;
  onPlayerChanged: () => void;
}

export default function ProfileTab({ player, onPlayerChanged }: Props) {
  const [name, setName] = useState(player.name);
  const [saved, setSaved] = useState(false);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const [practiceId, setPracticeId] = useState<string | null>(null);
  const [pace, setPace] = useState<Pace>('blitz');

  const save = async (): Promise<void> => {
    if (busy) {
      return;
    }
    setBusy(true);
    setMsg('');
    setSaved(false);
    try {
      unwrap<Player>(await api.put('/api/players/' + encodeURIComponent(player.playerId), { name }));
      setSaved(true);
      onPlayerChanged();
      window.setTimeout(() => setSaved(false), 1800);
    } catch (err) {
      setMsg(errorMessage(err, 'Could not save your name.'));
    } finally {
      setBusy(false);
    }
  };

  const practice = async (): Promise<void> => {
    if (busy) {
      return;
    }
    setBusy(true);
    setMsg('');
    try {
      const r = unwrap<RoundState>(await api.post('/api/rounds', { playerId: player.playerId, speed: SPEED, pace }));
      setPracticeId(r.roundId);
    } catch (err) {
      setMsg(errorMessage(err, 'Could not start a practice round.'));
    } finally {
      setBusy(false);
    }
  };

  if (practiceId) {
    return (
      <RoundPlay
        key={practiceId}
        roundId={practiceId}
        playerId={player.playerId}
        shareLabel="practice"
        onEnded={() => onPlayerChanged()}
        header={
          <div className="flex items-center justify-between px-1">
            <h2 className="text-lg font-black">Practice</h2>
            <span className="text-xs font-extrabold uppercase tracking-wide text-muted">No rating, no leaderboard</span>
          </div>
        }
        revealActions={() => (
          <>
            <button
              type="button"
              className="btn btn-primary flex-1"
              disabled={busy}
              onClick={() => {
                setPracticeId(null);
                void practice();
              }}
            >
              Another one
            </button>
            <button type="button" className="btn btn-ghost" onClick={() => setPracticeId(null)}>
              Done
            </button>
          </>
        )}
      />
    );
  }

  return (
    <div className="space-y-3">
      <div className="card p-4">
        <label className="text-xs font-extrabold uppercase tracking-wide text-muted" htmlFor="trader-name">
          Trader name
        </label>
        <div className="mt-1 flex gap-2">
          <input
            id="trader-name"
            className="input flex-1"
            value={name}
            maxLength={18}
            onChange={e => setName(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter') {
                void save();
              }
            }}
          />
          <button type="button" className="btn btn-primary" disabled={busy || name.trim().length < 2 || name === player.name} onClick={() => void save()}>
            {saved ? 'Saved' : 'Save'}
          </button>
        </div>
        {msg && (
          <p className="mt-2 text-sm font-bold text-coral" role="alert">
            {msg}
          </p>
        )}
        <p className="mt-2 text-xs font-bold text-muted">This is the name other traders see.</p>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <Stat label="Rating" value={String(player.rating)} />
        <Stat label="Lifetime P&L" value={fmtSigned(player.lifetimePnl)} tone={player.lifetimePnl > 0 ? 'up' : player.lifetimePnl < 0 ? 'down' : undefined} />
        <Stat label="Best round" value={fmtSigned(player.bestRound)} tone={player.bestRound > 0 ? 'up' : undefined} />
        <Stat label="Live wins" value={String(player.liveWins)} tone="up" />
        <Stat label="Duels" value={player.duelsWon + '–' + player.duelsLost} />
        <Stat label="Liquidated" value={String(player.liquidations)} tone={player.liquidations > 0 ? 'down' : undefined} />
      </div>

      <div className="card p-4">
        <h3 className="font-black">Practice</h3>
        <p className="mt-1 text-sm font-bold text-muted">Unlimited rounds. Nothing counts. Learn the feel of leverage before you duel.</p>
        <div className="mt-3 flex gap-1.5">
          {(['blitz', 'standard'] as Pace[]).map(p => (
            <button key={p} type="button" className={'lev flex-1 ' + (pace === p ? 'lev-active' : '')} onClick={() => setPace(p)} aria-pressed={pace === p}>
              {paceLabel(p)}
            </button>
          ))}
        </div>
        <button type="button" className="btn btn-ghost mt-2 w-full" disabled={busy} onClick={() => void practice()}>
          Start a practice round
        </button>
      </div>

      <div className="card p-4">
        <h3 className="font-black">How it works</h3>
        <ol className="mt-2 list-decimal space-y-1.5 pl-5 text-sm font-bold text-muted">
          <li>
            The price is the chance that one side wins a hidden match, from 0 to 100. You see a random slice of the match, and the round ends at a random time — nobody knows the ending.
          </li>
          <li>
            <span className="text-up">Long</span> if you think it goes up, <span className="text-coral">Short</span> if down. Your stake × leverage ÷ price = credits you make or lose per point. The trade bar shows the exact number before you tap.
          </li>
          <li>Move too far against you and you're liquidated — the stake is gone. Close early to lock profit, add to press a winner, flip to reverse.</li>
          <li>Blind AI traders push the price around like real noise. They can't see the ending either.</li>
          <li>Every round starts with 1,000 demo credits. You can't buy credits and you can't cash out. The score is how much you end with.</li>
        </ol>
      </div>
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: 'up' | 'down' }) {
  return (
    <div className="card px-3 py-2">
      <p className="text-[11px] font-extrabold uppercase tracking-wide text-muted">{label}</p>
      <p className={'text-xl font-black tabular ' + (tone === 'up' ? 'text-up' : tone === 'down' ? 'text-coral' : '')}>{value}</p>
    </div>
  );
}
