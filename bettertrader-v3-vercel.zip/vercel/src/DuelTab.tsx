import { useCallback, useEffect, useState } from 'react';
import { api } from './api';
import RoundPlay from './RoundPlay';
import { SPEED, errorMessage, fmtSigned, paceLabel, unwrap, type Duel, type Pace, type Player, type RoundState } from './lib';

interface Props {
  player: Player;
  onPlayerChanged: () => void;
}

const DUEL_KEY = 'bettertrader-duel-id';

export default function DuelTab({ player, onPlayerChanged }: Props) {
  const [duel, setDuel] = useState<Duel | null>(null);
  const [round, setRound] = useState<RoundState | null>(null);
  const [pace, setPace] = useState<Pace>('blitz');
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);

  const applyResponse = (res: { duel: Duel; round: RoundState | null }): void => {
    setDuel(res.duel);
    setRound(res.round);
    window.localStorage.setItem(DUEL_KEY, res.duel.duelId);
  };

  const refresh = useCallback(
    async (id: string): Promise<void> => {
      try {
        const res = unwrap<{ duel: Duel; round: RoundState | null }>(await api.get('/api/duels/' + encodeURIComponent(id) + '?playerId=' + encodeURIComponent(player.playerId)));
        setDuel(res.duel);
        setRound(res.round);
      } catch {
        window.localStorage.removeItem(DUEL_KEY);
        setDuel(null);
        setRound(null);
      }
    },
    [player.playerId]
  );

  useEffect(() => {
    const saved = window.localStorage.getItem(DUEL_KEY);
    if (saved) {
      void refresh(saved).finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [refresh]);

  // While live, poll the duel for the ghostAhead signal.
  useEffect(() => {
    if (!duel || !round || round.status === 'ended') {
      return;
    }
    const t = window.setInterval(() => void refresh(duel.duelId), 1000);
    return () => window.clearInterval(t);
  }, [duel, round, refresh]);

  const run = async (fn: () => Promise<{ duel: Duel; round: RoundState }>): Promise<void> => {
    if (busy) {
      return;
    }
    setBusy(true);
    setMsg('');
    try {
      applyResponse(await fn());
    } catch (err) {
      setMsg(errorMessage(err, 'Could not start. Try again.'));
    } finally {
      setBusy(false);
    }
  };

  const startDuel = (): Promise<void> => run(async () => unwrap(await api.post('/api/duels', { playerId: player.playerId, speed: SPEED, pace })));
  const nextRound = (): Promise<void> => run(async () => unwrap(await api.post('/api/duels/' + encodeURIComponent(duel!.duelId) + '/next', { playerId: player.playerId, speed: SPEED })));

  const onEnded = useCallback(() => {
    if (duel) {
      void refresh(duel.duelId).then(() => onPlayerChanged());
    }
  }, [duel, refresh, onPlayerChanged]);

  if (loading) {
    return <div className="card p-6 text-center font-extrabold">Loading…</div>;
  }

  if (!duel || !round) {
    return (
      <div className="space-y-3">
        <div className="card hero p-6">
          <p className="text-xs font-extrabold uppercase tracking-wide text-brand">Duel · best of 3 · vs AI</p>
          <h2 className="mt-1 text-3xl font-black leading-tight">Beat the ghost trader.</h2>
          <p className="mt-2 font-bold text-muted">Same hidden chart, same clock. More profit after each round takes the round. First to 2. The ghost can't see the future either.</p>
          <div className="mt-4 flex gap-1.5">
            {(['blitz', 'standard'] as Pace[]).map(p => (
              <button key={p} type="button" className={'lev flex-1 ' + (pace === p ? 'lev-active' : '')} onClick={() => setPace(p)} aria-pressed={pace === p}>
                {paceLabel(p)}
              </button>
            ))}
          </div>
          <button type="button" className="btn btn-primary mt-3 w-full text-lg" disabled={busy} onClick={() => void startDuel()}>
            Find a duel
          </button>
          {msg && <p className="mt-2 text-sm font-bold text-coral">{msg}</p>}
        </div>
        <div className="grid grid-cols-3 gap-2">
          <Stat label="Rating" value={String(player.rating)} />
          <Stat label="Won" value={String(player.duelsWon)} tone="up" />
          <Stat label="Lost" value={String(player.duelsLost)} tone="down" />
        </div>
      </div>
    );
  }

  const roundNo = duel.roundIds.length;
  const finished = duel.status !== 'live';
  const roundDone = round.status === 'ended';

  const scoreboard = (
    <div className="card flex items-center justify-between px-4 py-3">
      <div className="text-center">
        <p className="text-[11px] font-extrabold uppercase tracking-wide text-muted">You</p>
        <p className="text-3xl font-black tabular">{duel.playerWins}</p>
      </div>
      <div className="text-center">
        <p className="text-xs font-extrabold uppercase tracking-wide text-muted">Round {roundNo} · first to 2</p>
        <p className="text-sm font-black">vs {duel.ghostName}</p>
        <p className="text-[11px] font-bold text-muted">{duel.ghostBlurb}</p>
        {!roundDone && (
          <p className={'mt-0.5 text-[11px] font-black ' + (round.ghostAhead === true ? 'text-coral' : round.ghostAhead === false ? 'text-up' : 'text-muted')}>
            {round.ghostAhead === true ? 'Ghost is ahead' : round.ghostAhead === false ? 'You are ahead' : 'Dead even'}
          </p>
        )}
      </div>
      <div className="text-center">
        <p className="text-[11px] font-extrabold uppercase tracking-wide text-muted">{duel.ghostName}</p>
        <p className="text-3xl font-black tabular">{duel.ghostWins}</p>
      </div>
    </div>
  );

  return (
    <RoundPlay
      key={round.roundId}
      roundId={round.roundId}
      playerId={player.playerId}
      header={scoreboard}
      ahead={roundDone ? null : round.ghostAhead === true ? false : round.ghostAhead === false ? true : null}
      shareLabel={'Duel vs ' + duel.ghostName}
      onEnded={onEnded}
      revealExtra={() => (
        <div className={'card p-4 ' + (finished ? (duel.status === 'won' ? 'card-up' : duel.status === 'lost' ? 'card-down' : '') : '')}>
          {finished ? (
            <>
              <p className="text-xs font-extrabold uppercase tracking-wide text-muted">Duel over</p>
              <p className="text-2xl font-black">{duel.status === 'won' ? 'You beat ' + duel.ghostName + '!' : duel.status === 'lost' ? duel.ghostName + ' got you this time.' : 'Dead even. A draw.'}</p>
              <p className="mt-1 font-bold text-muted">
                {duel.playerWins}–{duel.ghostWins} · rating {duel.ratingDelta >= 0 ? '+' : ''}
                {duel.ratingDelta}
              </p>
            </>
          ) : (
            <p className="text-sm font-extrabold">{scoreline(duel)}</p>
          )}
          {duel.results.length > 0 && (
            <ol className="mt-2 space-y-1 text-sm">
              {duel.results.map((r, i) => (
                <li key={r.roundId} className="flex items-center justify-between">
                  <span className="font-bold text-muted">Round {i + 1}</span>
                  <span className="tabular">
                    <span className={r.playerPnl >= 0 ? 'text-up' : 'text-coral'}>{fmtSigned(r.playerPnl)}</span>
                    <span className="text-muted"> vs </span>
                    <span className={r.ghostPnl >= 0 ? 'text-up' : 'text-coral'}>{fmtSigned(r.ghostPnl)}</span>
                  </span>
                  <span className="w-20 text-right font-black">{r.winner === 'you' ? 'You' : r.winner === 'ghost' ? duel.ghostName : 'Tie'}</span>
                </li>
              ))}
            </ol>
          )}
          {msg && <p className="mt-2 text-sm font-bold text-coral">{msg}</p>}
        </div>
      )}
      revealActions={() =>
        finished ? (
          <button
            type="button"
            className="btn btn-primary flex-1"
            onClick={() => {
              window.localStorage.removeItem(DUEL_KEY);
              setDuel(null);
              setRound(null);
            }}
          >
            Back to duels
          </button>
        ) : (
          <button type="button" className="btn btn-primary flex-1" disabled={busy} onClick={() => void nextRound()}>
            Next round
          </button>
        )
      }
    />
  );
}

function scoreline(d: Duel): string {
  if (d.playerWins === d.ghostWins) {
    return 'All square at ' + d.playerWins + '–' + d.ghostWins + '. Next round decides momentum.';
  }
  return d.playerWins > d.ghostWins ? 'You lead ' + d.playerWins + '–' + d.ghostWins + '. One more.' : d.ghostName + ' leads ' + d.ghostWins + '–' + d.playerWins + '. Time to answer.';
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: 'up' | 'down' }) {
  return (
    <div className="card px-3 py-2">
      <p className="text-[11px] font-extrabold uppercase tracking-wide text-muted">{label}</p>
      <p className={'text-xl font-black tabular ' + (tone === 'up' ? 'text-up' : tone === 'down' ? 'text-coral' : '')}>{value}</p>
    </div>
  );
}
