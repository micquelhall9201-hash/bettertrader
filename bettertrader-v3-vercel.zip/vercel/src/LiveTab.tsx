import { useCallback, useEffect, useState } from 'react';
import { api } from './api';
import RoundPlay from './RoundPlay';
import { SPEED, errorMessage, fmtSigned, paceLabel, unwrap, type Pace, type Player, type Room } from './lib';

interface Props {
  player: Player;
  onPlayerChanged: () => void;
}

const ROOM_KEY = 'bettertrader-room-code';
const AI_WAIT = 15;

export default function LiveTab({ player, onPlayerChanged }: Props) {
  const [room, setRoom] = useState<Room | null>(null);
  const [pace, setPace] = useState<Pace>('blitz');
  const [code, setCode] = useState('');
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [waitSecs, setWaitSecs] = useState(AI_WAIT);

  const fetchRoom = useCallback(
    async (c: string): Promise<Room | null> => {
      try {
        let r = unwrap<Room>(await api.get('/api/rooms/' + encodeURIComponent(c) + '?playerId=' + encodeURIComponent(player.playerId)));
        if (!r.players.some(p => p.id === player.playerId)) {
          window.localStorage.removeItem(ROOM_KEY);
          return null;
        }
        if (r.status === 'ended' && r.nextCode) {
          r = unwrap<Room>(await api.get('/api/rooms/' + encodeURIComponent(r.nextCode) + '?playerId=' + encodeURIComponent(player.playerId)));
          window.localStorage.setItem(ROOM_KEY, r.code);
        }
        setRoom(r);
        return r;
      } catch {
        window.localStorage.removeItem(ROOM_KEY);
        setRoom(null);
        return null;
      }
    },
    [player.playerId]
  );

  useEffect(() => {
    const fromUrl = new URLSearchParams(window.location.search).get('room');
    const saved = window.localStorage.getItem(ROOM_KEY);
    const target = (fromUrl ?? saved ?? '').toUpperCase();
    if (!target) {
      setLoading(false);
      return;
    }
    (async () => {
      if (fromUrl && fromUrl.toUpperCase() !== saved) {
        try {
          const r = unwrap<Room>(await api.post('/api/rooms/join', { playerId: player.playerId, code: fromUrl.toUpperCase() }));
          window.localStorage.setItem(ROOM_KEY, r.code);
          setRoom(r);
        } catch (err) {
          setMsg(errorMessage(err, 'Could not join that room.'));
        }
      } else {
        await fetchRoom(target);
      }
      setLoading(false);
    })();
  }, [player.playerId, fetchRoom]);

  const roomCode = room?.code;
  const roomStatus = room?.status;
  useEffect(() => {
    if (!roomCode) {
      return;
    }
    const interval = roomStatus === 'lobby' ? 1500 : roomStatus === 'ended' ? 2500 : 700;
    const t = window.setInterval(() => void fetchRoom(roomCode), interval);
    return () => window.clearInterval(t);
  }, [roomCode, roomStatus, fetchRoom]);

  const humans = room ? room.players.filter(p => !p.bot).length : 0;
  const waitingPublic = !!room && room.status === 'lobby' && room.isPublic && humans < 2;
  useEffect(() => {
    if (!waitingPublic) {
      setWaitSecs(AI_WAIT);
      return;
    }
    const t = window.setInterval(() => setWaitSecs(s => Math.max(0, s - 1)), 1000);
    return () => window.clearInterval(t);
  }, [waitingPublic, roomCode]);

  const call = useCallback(
    async (fn: () => Promise<Room>): Promise<void> => {
      if (busy) {
        return;
      }
      setBusy(true);
      setMsg('');
      try {
        const r = await fn();
        window.localStorage.setItem(ROOM_KEY, r.code);
        setRoom(r);
      } catch (err) {
        setMsg(errorMessage(err, 'Something went wrong. Try again.'));
      } finally {
        setBusy(false);
      }
    },
    [busy]
  );

  const fill = useCallback(
    (): Promise<void> => call(async () => unwrap<Room>(await api.post('/api/rooms/' + encodeURIComponent(roomCode ?? '') + '/fill', { playerId: player.playerId }))),
    [call, roomCode, player.playerId]
  );

  useEffect(() => {
    if (waitingPublic && waitSecs === 0) {
      void fill();
    }
  }, [waitingPublic, waitSecs, fill]);

  const quick = (): Promise<void> => call(async () => unwrap<Room>(await api.post('/api/rooms/quick', { playerId: player.playerId, pace, speed: SPEED })));
  const create = (): Promise<void> => call(async () => unwrap<Room>(await api.post('/api/rooms', { playerId: player.playerId, pace, isPublic: false, speed: SPEED })));
  const join = (): Promise<void> => call(async () => unwrap<Room>(await api.post('/api/rooms/join', { playerId: player.playerId, code: code.trim().toUpperCase() })));
  const start = (): Promise<void> => call(async () => unwrap<Room>(await api.post('/api/rooms/' + encodeURIComponent(room!.code) + '/start', { playerId: player.playerId })));
  const rematch = (): Promise<void> => call(async () => unwrap<Room>(await api.post('/api/rooms/' + encodeURIComponent(room!.code) + '/rematch', { playerId: player.playerId })));

  const leave = async (): Promise<void> => {
    const c = room?.code;
    window.localStorage.removeItem(ROOM_KEY);
    setRoom(null);
    setMsg('');
    if (c) {
      try {
        await api.post('/api/rooms/' + encodeURIComponent(c) + '/leave', { playerId: player.playerId });
      } catch {
        // ignore
      }
    }
    if (window.location.search.includes('room=')) {
      window.history.replaceState(null, '', window.location.pathname);
    }
  };

  const inviteLink = room ? window.location.origin + window.location.pathname + '?room=' + room.code : '';
  const copyInvite = async (): Promise<void> => {
    try {
      await navigator.clipboard.writeText(inviteLink);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  };

  if (loading) {
    return <div className="card p-6 text-center font-extrabold">Loading…</div>;
  }

  if (!room) {
    return (
      <div className="space-y-3">
        <div className="card hero p-6">
          <p className="text-xs font-extrabold uppercase tracking-wide text-brand">Live · up to 8 traders</p>
          <h2 className="mt-1 text-3xl font-black leading-tight">Same chart. Same clock. Most money wins.</h2>
          <p className="mt-2 font-bold text-muted">Everyone in the room trades the identical hidden chart. You only see who's in and who got liquidated — the glow tells you if you're winning. P&L drops at the end.</p>
          <div className="mt-4 flex gap-1.5">
            {(['blitz', 'standard'] as Pace[]).map(p => (
              <button key={p} type="button" className={'lev flex-1 ' + (pace === p ? 'lev-active' : '')} onClick={() => setPace(p)} aria-pressed={pace === p}>
                {paceLabel(p)}
              </button>
            ))}
          </div>
          <button type="button" className="btn btn-primary mt-3 w-full text-lg" disabled={busy} onClick={() => void quick()}>
            Quick match
          </button>
          <button type="button" className="btn btn-ghost mt-2 w-full" disabled={busy} onClick={() => void create()}>
            Make a private room
          </button>
          <p className="mt-2 text-center text-[11px] font-bold text-muted">Nobody online? AI traders fill the room after {AI_WAIT} seconds.</p>
          {msg && <p className="mt-2 text-sm font-bold text-coral">{msg}</p>}
        </div>
        <div className="card p-4">
          <p className="text-xs font-extrabold uppercase tracking-wide text-muted">Have a code?</p>
          <div className="mt-1 flex gap-2">
            <input
              className="input flex-1 uppercase tracking-widest"
              value={code}
              maxLength={4}
              placeholder="ABCD"
              onChange={e => setCode(e.target.value.toUpperCase())}
              onKeyDown={e => {
                if (e.key === 'Enter') {
                  void join();
                }
              }}
              aria-label="Room code"
            />
            <button type="button" className="btn btn-primary" disabled={busy || code.trim().length !== 4} onClick={() => void join()}>
              Join
            </button>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Stat label="Live wins" value={String(player.liveWins)} tone="up" />
          <Stat label="Rating" value={String(player.rating)} />
        </div>
      </div>
    );
  }

  if (room.status === 'lobby') {
    return (
      <div className="space-y-3">
        <div className="card p-5 text-center">
          <p className="text-xs font-extrabold uppercase tracking-wide text-muted">Room code</p>
          <p className="text-5xl font-black tracking-[0.3em] text-brand">{room.code}</p>
          <p className="mt-1 text-sm font-bold text-muted">
            {paceLabel(room.pace)} · {room.isPublic ? 'public' : 'private'}
          </p>
          <div className="mt-3 flex gap-2">
            <button type="button" className="btn btn-ghost flex-1" onClick={() => void copyInvite()}>
              {copied ? 'Link copied!' : 'Copy invite link'}
            </button>
            <button type="button" className="btn btn-ghost" onClick={() => void leave()}>
              Leave
            </button>
          </div>
        </div>
        <div className="card">
          <div className="flex items-center justify-between px-4 py-3">
            <h3 className="font-black">In the room</h3>
            <span className="text-xs font-extrabold text-muted">
              {room.players.length}/{room.maxPlayers}
            </span>
          </div>
          <ul className="divide-y-2 divide-line border-t-2 border-line">
            {room.players.map(p => (
              <li key={p.id} className="flex items-center justify-between px-4 py-2 font-bold">
                <span>
                  {p.name}
                  {p.id === player.playerId ? ' (you)' : ''}
                </span>
                {p.bot ? <span className="text-[11px] font-extrabold uppercase tracking-wide text-ghost">AI</span> : p.id === room.hostId ? <span className="text-[11px] font-extrabold uppercase tracking-wide text-muted">host</span> : null}
              </li>
            ))}
          </ul>
        </div>
        <button type="button" className="btn btn-primary w-full text-lg" disabled={busy || room.players.length < 2} onClick={() => void start()}>
          {room.players.length >= 2 ? 'Start the round' : waitingPublic ? 'Finding traders… AI joins in ' + waitSecs : 'Waiting for one more…'}
        </button>
        {room.players.length < 2 && (
          <button type="button" className="btn btn-ghost w-full" disabled={busy} onClick={() => void fill()}>
            Play vs AI traders now
          </button>
        )}
        <p className="text-center text-xs font-bold text-muted">{room.players.length < 2 ? 'Send the link to a friend, or let the AI traders fill in.' : 'Anyone in the room can start.'}</p>
        {msg && <p className="text-center text-sm font-bold text-coral">{msg}</p>}
      </div>
    );
  }

  const standings = (
    <div className="card px-4 py-2">
      <div className="flex items-center justify-between">
        <span className="text-xs font-extrabold uppercase tracking-wide text-muted">
          Room {room.code} · {room.players.length} traders
        </span>
        {room.status === 'live' && (
          <span className={'text-xs font-black ' + (room.ahead === true ? 'text-up' : room.ahead === false ? 'text-coral' : 'text-muted')}>
            {room.ahead === true ? 'You are winning' : room.ahead === false ? 'You are behind' : 'Dead even'}
          </span>
        )}
      </div>
      <div className="mt-1 flex flex-wrap gap-1.5">
        {room.standings.map(s => (
          <span key={s.id} className={'bot ' + (s.liquidated ? 'bot-sell' : s.trading ? 'bot-buy' : 'bot-idle')}>
            {s.name}
            {s.id === player.playerId ? ' (you)' : ''}
            {s.liquidated ? ' · liq' : s.trading ? ' · in' : ''}
          </span>
        ))}
      </div>
    </div>
  );

  if (!room.viewerRoundId) {
    return (
      <div className="space-y-3">
        {standings}
        <div className="card p-6 text-center font-extrabold">Setting up your chart…</div>
      </div>
    );
  }

  return (
    <RoundPlay
      key={room.viewerRoundId}
      roundId={room.viewerRoundId}
      playerId={player.playerId}
      header={standings}
      ahead={room.status === 'live' ? room.ahead : null}
      shareLabel={'Live room ' + room.code}
      onEnded={() => {
        void fetchRoom(room.code).then(() => onPlayerChanged());
      }}
      revealExtra={() =>
        room.status === 'ended' ? (
          <div className="card">
            <div className="flex items-center justify-between px-4 py-3">
              <h3 className="font-black">Final standings</h3>
              <span className={'text-xs font-extrabold ' + (room.winnerName ? 'text-up' : 'text-muted')}>{room.winnerName ? room.winnerName + ' wins' : 'Tie'}</span>
            </div>
            <ol className="divide-y-2 divide-line border-t-2 border-line">
              {room.standings.map((s, i) => (
                <li key={s.id} className={'flex items-center gap-3 px-4 py-2 ' + (s.id === player.playerId ? 'bg-brand/10' : '')}>
                  <span className="w-6 text-sm font-black text-muted">{i + 1}</span>
                  <span className="flex-1 truncate font-bold">
                    {s.name}
                    {s.id === player.playerId ? ' (you)' : ''}
                    {s.liquidated ? <span className="ml-1 text-[11px] font-extrabold uppercase text-coral">liq</span> : null}
                  </span>
                  <span className={'font-black tabular ' + ((s.pnl ?? 0) > 0 ? 'text-up' : (s.pnl ?? 0) < 0 ? 'text-coral' : '')}>{fmtSigned(s.pnl ?? 0)}</span>
                </li>
              ))}
            </ol>
          </div>
        ) : (
          <div className="card p-4 text-center text-sm font-bold text-muted">Waiting for everyone to finish…</div>
        )
      }
      revealActions={() => (
        <>
          <button type="button" className="btn btn-primary flex-1" disabled={busy || room.status !== 'ended'} onClick={() => void rematch()}>
            {room.status !== 'ended' ? 'Waiting…' : 'Rematch'}
          </button>
          <button type="button" className="btn btn-ghost" onClick={() => void leave()}>
            Leave
          </button>
        </>
      )}
    />
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: 'up' | 'down' }) {
  return (
    <div className="card px-3 py-2">
      <p className="text-[11px] font-extrabold uppercase tracking-wide text-muted">{label}</p>
      <p className={'text-xl font-black tabular ' + (tone === 'up' ? 'text-up' : tone === 'down' ? 'text-coral' : '')}>{value}</p>
    </div>
  );
}
