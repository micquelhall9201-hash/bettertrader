import { api } from './api';

export type Side = 'long' | 'short';
export type Status = 'pending' | 'live' | 'ended';
export type Mode = 'daily' | 'duel' | 'practice' | 'live';
export type Pace = 'blitz' | 'standard';

export interface Position {
  side: Side;
  margin: number;
  lev: number;
  entryPrice: number;
  qty: number;
  entryTick: number;
  liqPrice: number;
}

export interface Trade {
  side: Side;
  margin: number;
  lev: number;
  entryPrice: number;
  exitPrice: number;
  entryTick: number;
  exitTick: number;
  pnl: number;
  kind: 'close' | 'liquidated' | 'settled';
}

export interface BotAction {
  t: number;
  bot: string;
  side: 'buy' | 'sell' | 'warn';
  size: number;
}

export interface BotInfo {
  id: string;
  name: string;
  style: string;
  blurb: string;
}

export interface Reveal {
  label: string;
  sideA: string;
  sideB: string;
  competition: string;
  winner: string;
  windowText: string;
  generator: string;
  seed: number;
  note: string;
}

export interface Ghost {
  name: string;
  style: string;
  blurb: string;
  trades: Trade[];
  pnl: number;
}

export interface RoundState {
  roundId: string;
  mode: Mode;
  pace: Pace;
  duelId: string | null;
  roomCode: string | null;
  status: Status;
  tickIndex: number;
  tickMs: number;
  startTs: number;
  totalTicks: number;
  serverNow: number;
  cash: number;
  roundCash: number;
  pos: Position | null;
  trades: Trade[];
  bots: BotInfo[];
  leverages: number[];
  ghostName: string | null;
  ghostBlurb: string | null;
  ghostAhead?: boolean | null;
  prices: number[];
  botLog: BotAction[];
  truePrices?: number[];
  reveal?: Reveal;
  finalValue?: number;
  pnl?: number;
  ghost?: Ghost | null;
}

export interface Player {
  playerId: string;
  name: string;
  rating: number;
  lifetimePnl: number;
  roundsPlayed: number;
  duelsWon: number;
  duelsLost: number;
  liveWins: number;
  liquidations: number;
  bestRound: number;
  dailyStreak: number;
  lastDailyDate: string | null;
}

export interface DailyInfo {
  date: string;
  resetsAt: number;
  serverNow: number;
  played: boolean;
  roundId: string | null;
  settled: boolean;
  pnl: number | null;
  streak: number;
  board: Array<{ playerId: string; name: string; pnl: number }>;
  players: number;
}

export interface DuelResult {
  roundId: string;
  playerPnl: number;
  ghostPnl: number;
  winner: 'you' | 'ghost' | 'tie';
}

export interface Duel {
  duelId: string;
  ghostName: string;
  ghostStyle: string;
  ghostBlurb: string;
  pace: Pace;
  bestOf: number;
  roundIds: string[];
  results: DuelResult[];
  playerWins: number;
  ghostWins: number;
  status: 'live' | 'won' | 'lost' | 'draw';
  ratingDelta: number;
  currentRoundId: string | null;
}

export interface RoomStanding {
  id: string;
  name: string;
  pnl?: number | null;
  trading?: boolean;
  liquidated: boolean;
}

export interface Room {
  code: string;
  hostId: string;
  pace: Pace;
  isPublic: boolean;
  status: 'lobby' | 'live' | 'ended';
  players: Array<{ id: string; name: string; bot?: string }>;
  startTs: number | null;
  ticks: number | null;
  serverNow: number;
  viewerRoundId: string | null;
  ahead: boolean | null;
  anyLive: boolean;
  standings: RoomStanding[];
  winnerName: string | null;
  maxPlayers: number;
  nextCode: string | null;
  humans: number;
}

export const PLAYER_KEY = 'bettertrader-player-id';
export const SPEED: 'normal' | 'fast' =
  new URLSearchParams(window.location.search).get('speed') === 'fast' ? 'fast' : 'normal';

export function unwrap<T>(res: { data: unknown }): T {
  const data = res.data as { error?: unknown } | null;
  if (data && typeof data === 'object' && typeof data.error === 'string') {
    throw new Error(data.error);
  }
  return res.data as T;
}

export function errorMessage(err: unknown, fallback: string): string {
  if (typeof err === 'object' && err !== null) {
    const e = err as { response?: { data?: { error?: unknown } }; data?: { error?: unknown }; message?: unknown };
    const fromBody = e.response?.data?.error ?? e.data?.error;
    if (typeof fromBody === 'string' && fromBody) {
      return fromBody;
    }
    if (typeof e.message === 'string' && e.message && !/^Request failed/i.test(e.message)) {
      return e.message;
    }
  }
  return fallback;
}

export async function ensurePlayer(): Promise<Player> {
  const saved = window.localStorage.getItem(PLAYER_KEY);
  if (saved) {
    try {
      return unwrap<Player>(await api.get('/api/players/' + encodeURIComponent(saved)));
    } catch {
      window.localStorage.removeItem(PLAYER_KEY);
    }
  }
  const created = unwrap<Player>(await api.post('/api/players', {}));
  window.localStorage.setItem(PLAYER_KEY, created.playerId);
  return created;
}

export function fmtCredits(n: number): string {
  return Math.round(n).toLocaleString();
}

export function fmtSigned(n: number): string {
  const r = Math.round(n);
  if (r === 0) {
    return '±0';
  }
  return (r > 0 ? '+' : '−') + Math.abs(r).toLocaleString();
}

export function fmtPrice(p: number): string {
  return p.toFixed(2);
}

export function fmtClock(totalSeconds: number): string {
  const s = Math.max(0, Math.ceil(totalSeconds));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return m + ':' + (r < 10 ? '0' : '') + r;
}

export function fmtCountdown(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 0) {
    return h + 'h ' + (m < 10 ? '0' : '') + m + 'm';
  }
  const r = s % 60;
  return m + ':' + (r < 10 ? '0' : '') + r;
}

export function fmtDateLong(iso: string): string {
  const d = new Date(iso + 'T00:00:00Z');
  return d.toLocaleDateString(undefined, { month: 'long', day: 'numeric', timeZone: 'UTC' });
}

export function unrealized(pos: Position, price: number): number {
  const raw = pos.side === 'long' ? pos.qty * (price - pos.entryPrice) : pos.qty * (pos.entryPrice - price);
  return Math.max(raw, -pos.margin);
}

export function paceLabel(p: Pace): string {
  return p === 'blitz' ? 'Blitz · 20–40s' : 'Standard · 1–2½ min';
}
