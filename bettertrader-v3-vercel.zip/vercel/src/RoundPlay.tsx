import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { api } from './api';
import Chart, { type Level, type Marker } from './Chart';
import { sfx } from './sound';
import {
  errorMessage,
  fmtClock,
  fmtCredits,
  fmtPrice,
  fmtSigned,
  unrealized,
  unwrap,
  type BotAction,
  type RoundState,
  type Side,
  type Trade,
} from './lib';

interface Props {
  roundId: string;
  playerId: string;
  header?: ReactNode;
  ahead?: boolean | null;
  onEnded?: (round: RoundState) => void;
  revealActions?: (round: RoundState) => ReactNode;
  revealExtra?: (round: RoundState) => ReactNode;
  shareLabel?: string;
}

const LEV_KEY = 'bettertrader-lev';

export default function RoundPlay({ roundId, playerId, header, ahead, onEnded, revealActions, revealExtra, shareLabel }: Props) {
  const [round, setRound] = useState<RoundState | null>(null);
  const [offset, setOffset] = useState(0);
  const [now, setNow] = useState(Date.now());
  const [msg, setMsg] = useState('');
  const [pending, setPending] = useState('');
  const [margin, setMargin] = useState(250);
  const [lev, setLev] = useState(() => Number(window.localStorage.getItem(LEV_KEY)) || 2);
  const [liqFlash, setLiqFlash] = useState(false);
  const [pop, setPop] = useState(0);
  const endedRef = useRef(false);
  const onEndedRef = useRef(onEnded);
  onEndedRef.current = onEnded;
  const liqCountRef = useRef(0);
  const warnRef = useRef(-1);
  const lastPriceRef = useRef<number | null>(null);

  const apply = useCallback((state: RoundState) => {
    setRound(state);
    setOffset(state.serverNow - Date.now());
  }, []);

  useEffect(() => {
    endedRef.current = false;
    liqCountRef.current = 0;
    warnRef.current = -1;
    lastPriceRef.current = null;
    let cancelled = false;
    let timer: number | null = null;
    const poll = async (): Promise<void> => {
      try {
        const state = unwrap<RoundState>(await api.get('/api/rounds/' + encodeURIComponent(roundId) + '?playerId=' + encodeURIComponent(playerId)));
        if (cancelled) {
          return;
        }
        apply(state);
        if (state.status === 'ended') {
          if (!endedRef.current) {
            endedRef.current = true;
            onEndedRef.current?.(state);
            if ((state.pnl ?? 0) > 0) {
              sfx.win();
            }
          }
          return;
        }
        timer = window.setTimeout(() => void poll(), Math.max(250, Math.min(900, state.tickMs)));
      } catch (err) {
        if (!cancelled) {
          setMsg(errorMessage(err, 'Connection hiccup. Retrying…'));
          timer = window.setTimeout(() => void poll(), 1200);
        }
      }
    };
    void poll();
    return () => {
      cancelled = true;
      if (timer !== null) {
        window.clearTimeout(timer);
      }
    };
  }, [roundId, playerId, apply]);

  // Liquidation hit, sniper warning, big-move pop.
  useEffect(() => {
    if (!round || round.status === 'ended') {
      return;
    }
    const liqs = round.trades.filter(t => t.kind === 'liquidated').length;
    if (liqs > liqCountRef.current) {
      setLiqFlash(true);
      sfx.liq();
      try {
        navigator.vibrate?.([60, 40, 160]);
      } catch {
        // ignore
      }
      window.setTimeout(() => setLiqFlash(false), 1400);
    }
    liqCountRef.current = liqs;
    const warn = [...round.botLog].reverse().find(a => a.side === 'warn');
    if (warn && warn.t > warnRef.current) {
      warnRef.current = warn.t;
      sfx.warn();
    }
    const p = round.prices.length ? round.prices[round.prices.length - 1] : null;
    if (p !== null && lastPriceRef.current !== null && Math.abs(p - lastPriceRef.current) >= 2) {
      setPop(x => x + 1);
      sfx.tick();
    }
    lastPriceRef.current = p;
  }, [round]);

  const live = round !== null && round.status !== 'ended';
  useEffect(() => {
    if (!live) {
      return;
    }
    let raf = 0;
    const loop = (): void => {
      setNow(Date.now());
      raf = window.requestAnimationFrame(loop);
    };
    raf = window.requestAnimationFrame(loop);
    return () => window.cancelAnimationFrame(raf);
  }, [live]);

  const serverNow = now + offset;
  const price = round && round.prices.length ? round.prices[round.prices.length - 1] : null;
  const markers = useMemo<Marker[]>(() => (round ? tradeMarkers(round.trades, round.pos) : []), [round]);

  const act = async (label: string, body: Record<string, unknown>): Promise<void> => {
    if (!round || pending) {
      return;
    }
    setPending(label);
    setMsg('');
    try {
      const res = unwrap<{ pos: RoundState['pos']; trades: Trade[]; cash: number; price: number }>(
        await api.post('/api/rounds/' + encodeURIComponent(round.roundId) + '/trade', { playerId, ...body })
      );
      const before = round.trades.length;
      setRound({ ...round, pos: res.pos, trades: res.trades, cash: res.cash });
      if (res.trades.length > before) {
        const last = res.trades[res.trades.length - 1];
        if (last.pnl > 0) {
          sfx.cash();
        } else {
          sfx.loss();
        }
        setMsg((last.pnl >= 0 ? 'Locked ' : 'Took ') + fmtSigned(last.pnl) + ' at ' + fmtPrice(last.exitPrice));
      } else if (res.pos) {
        sfx.open();
        setMsg('Filled ' + res.pos.side + ' ' + res.pos.lev + 'x at ' + fmtPrice(res.pos.entryPrice));
      }
      window.setTimeout(() => setMsg(m => (m.startsWith('Filled') || m.startsWith('Locked') || m.startsWith('Took') ? '' : m)), 1600);
    } catch (err) {
      setMsg(errorMessage(err, 'That did not go through. Try again.'));
    } finally {
      setPending('');
    }
  };

  const skip = async (): Promise<void> => {
    if (!round || pending) {
      return;
    }
    setPending('Skipping…');
    try {
      apply(unwrap<RoundState>(await api.post('/api/rounds/' + encodeURIComponent(round.roundId) + '/skip', { playerId })));
    } catch (err) {
      setMsg(errorMessage(err, 'Could not skip.'));
    } finally {
      setPending('');
    }
  };

  if (!round) {
    return (
      <div className="card p-6 text-center">
        <p className="text-lg font-extrabold">Loading the chart…</p>
        {msg && <p className="mt-2 text-sm text-coral">{msg}</p>}
      </div>
    );
  }

  if (round.status === 'ended') {
    return (
      <RevealView round={round} shareLabel={shareLabel} extra={revealExtra?.(round)}>
        {revealActions?.(round)}
      </RevealView>
    );
  }

  const endTs = round.startTs + (round.totalTicks - 1) * round.tickMs;
  const isPending = serverNow < round.startTs;
  const remaining = Math.max(0, (endTs - serverNow) / 1000);
  const headIdx = round.prices.length - 1;
  const tickStart = round.startTs + headIdx * round.tickMs;
  const headProgress = headIdx <= 0 ? 1 : Math.max(0, Math.min(1, (serverNow - tickStart) / round.tickMs));

  const pos = round.pos;
  const uPnl = pos && price !== null ? unrealized(pos, price) : 0;
  const equity = round.cash + (pos ? pos.margin + uPnl : 0);
  const totalPnl = equity - round.roundCash;
  const maxMargin = Math.floor(round.cash);
  const stake = Math.min(margin, Math.max(1, maxMargin));
  const tone: 'neutral' | 'up' | 'down' = pos ? (uPnl > 0 ? 'up' : uPnl < 0 ? 'down' : 'neutral') : 'neutral';
  const levels: Level[] = pos
    ? [
        { price: pos.entryPrice, kind: 'entry', label: 'ENTRY ' + fmtPrice(pos.entryPrice) },
        { price: pos.liqPrice, kind: 'liq', label: 'LIQ ' + fmtPrice(pos.liqPrice) },
      ]
    : [];
  const flash = ahead === true ? 'flash-up' : ahead === false ? 'flash-down' : '';
  const lastMove = price !== null && round.prices.length > 1 ? price - round.prices[round.prices.length - 2] : 0;
  const perPoint = price ? (stake * lev) / price : 0;
  const liqLong = price ? price * (1 - 1 / lev) : 0;
  const liqShort = price ? price * (1 + 1 / lev) : 0;
  const broke = !pos && round.cash < 1;
  const canSkip = broke && (round.mode === 'practice' || round.mode === 'duel');
  const warnLive = round.botLog.length && round.botLog[round.botLog.length - 1].side === 'warn';

  return (
    <div className={'space-y-3 pb-56 ' + flash}>
      {liqFlash && (
        <div className="liq-hit" role="alert">
          <p className="text-5xl font-black">LIQUIDATED</p>
          <p className="mt-1 font-extrabold">Stake gone. Chart's still moving.</p>
        </div>
      )}
      {header}
      <div className="card chartcard overflow-hidden">
        <div className="flex items-center justify-between px-4 pt-3">
          <div className="flex items-baseline gap-2">
            <span key={pop} className={'pop text-4xl font-black tabular ' + (lastMove > 0 ? 'text-up' : lastMove < 0 ? 'text-coral' : '')}>
              {price === null ? '—' : fmtPrice(price)}
            </span>
            {price !== null && lastMove !== 0 && (
              <span className={'text-sm font-black ' + (lastMove > 0 ? 'text-up' : 'text-coral')}>
                {lastMove > 0 ? '▲' : '▼'} {Math.abs(lastMove).toFixed(2)}
              </span>
            )}
          </div>
          <div className={'text-2xl font-black tabular ' + (remaining <= 10 && !isPending ? 'text-coral' : '')}>
            {isPending ? 'Starts in ' + Math.ceil((round.startTs - serverNow) / 1000) : fmtClock(remaining)}
          </div>
        </div>
        <Chart prices={round.prices} totalTicks={round.totalTicks} secondsPerTick={round.tickMs / 1000} headProgress={headProgress} live markers={markers} levels={levels} tone={tone} height={300} />
        <Ticker log={round.botLog} bots={round.bots} />
      </div>

      <div className="grid grid-cols-3 gap-2">
        <Stat label="Cash" value={fmtCredits(round.cash)} />
        <Stat label="Open P&L" value={pos ? fmtSigned(uPnl) : '—'} tone={pos ? (uPnl >= 0 ? 'up' : 'down') : undefined} sub={pos ? pos.lev + 'x ' + pos.side + ' · ' + fmtCredits(pos.margin) + ' in' : 'no position'} />
        <Stat label="Round P&L" value={fmtSigned(totalPnl)} tone={totalPnl >= 0 ? 'up' : 'down'} sub={'total ' + fmtCredits(equity)} />
      </div>

      {warnLive ? (
        <p className="text-center text-sm font-black text-coral">⚠ SNIPER is loading a big move. Which way? Nobody knows.</p>
      ) : (
        <p className="text-center text-xs text-muted">Demo credits only — nothing to buy or cash out.</p>
      )}

      <div className="tradebar">
        <div className="mx-auto max-w-2xl px-3 pb-2 pt-2">
          {!pos ? (
            broke ? (
              <div className="flex items-center justify-between gap-3">
                <p className="text-sm font-extrabold text-coral">You're out of credits for this round.</p>
                {canSkip ? (
                  <button type="button" className="btn btn-primary" disabled={!!pending} onClick={() => void skip()}>
                    Skip to reveal
                  </button>
                ) : (
                  <span className="text-xs font-bold text-muted">Watch it play out.</span>
                )}
              </div>
            ) : (
              <>
                <div className="flex items-center gap-1.5">
                  {round.leverages.map(l => (
                    <button
                      key={l}
                      type="button"
                      className={'lev ' + (lev === l ? 'lev-active' : '')}
                      onClick={() => {
                        setLev(l);
                        window.localStorage.setItem(LEV_KEY, String(l));
                      }}
                      aria-pressed={lev === l}
                    >
                      {l}x
                    </button>
                  ))}
                  <input
                    type="number"
                    min={1}
                    max={maxMargin}
                    value={margin}
                    onChange={e => setMargin(Math.max(1, Math.floor(Number(e.target.value) || 1)))}
                    className="input w-20 text-right"
                    aria-label="Stake"
                  />
                  <button type="button" className="chip" onClick={() => setMargin(Math.max(1, maxMargin))}>
                    Max
                  </button>
                </div>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  <button type="button" className="btn btn-long text-lg" disabled={!!pending || isPending || price === null} onClick={() => void act('Opening long…', { action: 'open', side: 'long', margin: stake, lev })}>
                    {pending === 'Opening long…' ? pending : 'Long ▲'}
                  </button>
                  <button type="button" className="btn btn-short text-lg" disabled={!!pending || isPending || price === null} onClick={() => void act('Opening short…', { action: 'open', side: 'short', margin: stake, lev })}>
                    {pending === 'Opening short…' ? pending : 'Short ▼'}
                  </button>
                </div>
                <p className="mt-1.5 text-center text-[11px] font-bold text-muted">
                  {fmtCredits(stake)} at {lev}x = <span className="text-ink">{perPoint.toFixed(0)} credits per point</span>
                  {price !== null && (
                    <>
                      {' '}· liq at {fmtPrice(liqLong)} (long) / {fmtPrice(liqShort)} (short)
                    </>
                  )}
                </p>
              </>
            )
          ) : (
            <>
              <div className="flex items-center justify-between">
                <p className="text-sm font-bold">
                  <span className={pos.side === 'long' ? 'text-up' : 'text-coral'}>{pos.side.toUpperCase()} {pos.lev}x</span> · in {fmtPrice(pos.entryPrice)} · liq {fmtPrice(pos.liqPrice)}
                </p>
                <span className={'text-2xl font-black tabular ' + (uPnl >= 0 ? 'text-up' : 'text-coral')}>{fmtSigned(uPnl)}</span>
              </div>
              <div className="mt-2 grid grid-cols-4 gap-1.5">
                <button type="button" className="btn btn-sell col-span-2 text-base" disabled={!!pending} onClick={() => void act('Closing…', { action: 'close', fraction: 1 })}>
                  {pending === 'Closing…' ? pending : 'Close all'}
                </button>
                <button type="button" className="btn btn-ghost px-2 text-sm" disabled={!!pending} onClick={() => void act('Closing 50%…', { action: 'close', fraction: 0.5 })}>
                  {pending === 'Closing 50%…' ? '…' : 'Close ½'}
                </button>
                <button type="button" className={'btn px-2 text-sm ' + (pos.side === 'long' ? 'btn-short' : 'btn-long')} disabled={!!pending} onClick={() => void act('Flipping…', { action: 'flip' })}>
                  {pending === 'Flipping…' ? '…' : 'Flip'}
                </button>
              </div>
              {maxMargin >= 1 && (
                <button type="button" className="btn btn-ghost mt-1.5 w-full py-2 text-sm" disabled={!!pending} onClick={() => void act('Adding…', { action: 'add', margin: Math.min(margin, maxMargin) })}>
                  {pending === 'Adding…' ? pending : 'Add ' + fmtCredits(Math.min(margin, maxMargin)) + ' more'}
                </button>
              )}
            </>
          )}
          {msg && (
            <p className={'mt-1 text-center text-xs font-black ' + (msg.startsWith('Locked') || msg.startsWith('Filled') ? 'text-up' : 'text-coral')} role="status">
              {msg}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

export function tradeMarkers(trades: Trade[], pos: RoundState['pos']): Marker[] {
  const out: Marker[] = [];
  for (const t of trades) {
    out.push({ tick: t.entryTick, price: t.entryPrice, kind: t.side, label: (t.side === 'long' ? 'L' : 'S') + t.lev + 'x' });
    out.push({ tick: t.exitTick, price: t.exitPrice, kind: t.kind === 'liquidated' ? 'liq' : 'exit', label: t.kind === 'liquidated' ? 'LIQ ' + fmtSigned(t.pnl) : fmtSigned(t.pnl) });
  }
  if (pos) {
    out.push({ tick: pos.entryTick, price: pos.entryPrice, kind: pos.side, label: (pos.side === 'long' ? 'L' : 'S') + pos.lev + 'x' });
  }
  return out;
}

function Stat({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone?: 'up' | 'down' }) {
  return (
    <div className="card px-3 py-2">
      <p className="text-[11px] font-extrabold uppercase tracking-wide text-muted">{label}</p>
      <p className={'text-xl font-black tabular ' + (tone === 'up' ? 'text-up' : tone === 'down' ? 'text-coral' : '')}>{value}</p>
      {sub && <p className="truncate text-xs font-bold text-muted">{sub}</p>}
    </div>
  );
}

const VERB: Record<string, string> = { buy: 'bought', sell: 'sold', warn: 'is LOADING' };

function Ticker({ log, bots }: { log: BotAction[]; bots: RoundState['bots'] }) {
  const nameOf = (id: string): string => bots.find(b => b.id === id)?.name ?? id.toUpperCase();
  const recent = log.slice(-6).reverse();
  const items = recent.length
    ? recent.map(a => nameOf(a.bot) + ' ' + VERB[a.side] + (a.side === 'warn' ? ' a big one' : a.size === 3 ? ' BIG' : a.size === 2 ? '' : ' a bit'))
    : ['Market opening…', 'AI traders are watching…'];
  const last = recent[0];
  return (
    <div className="flex items-center gap-2 overflow-x-auto border-t-2 border-line px-3 py-2">
      <span className="shrink-0 text-[11px] font-extrabold uppercase tracking-wide text-muted">Tape</span>
      {last && last.side === 'warn' && <span className="bot bot-warn">⚠ {nameOf(last.bot)} LOADING</span>}
      {items.map((txt, i) => (
        <span key={i} className={'bot ' + (txt.includes('bought') ? 'bot-buy' : txt.includes('sold') ? 'bot-sell' : 'bot-idle')}>
          {txt}
        </span>
      ))}
    </div>
  );
}

export function RevealView({ round, children, shareLabel, extra }: { round: RoundState; children?: ReactNode; shareLabel?: string; extra?: ReactNode }) {
  const [copied, setCopied] = useState(false);
  const r = round.reveal;
  const pnl = round.pnl ?? 0;
  const won = pnl > 0;
  const liqs = round.trades.filter(t => t.kind === 'liquidated').length;
  const markers = tradeMarkers(round.trades, null);
  const ghost = round.ghost;
  if (ghost) {
    ghost.trades.forEach(t => {
      markers.push({ tick: t.entryTick, price: t.entryPrice, kind: 'ghost', label: ghost.name + (t.side === 'long' ? '▲' : '▼') });
    });
  }

  const share = async (): Promise<void> => {
    const lines = [
      'BetterTrader ' + (shareLabel ?? 'round') + ' · ' + fmtSigned(pnl) + (won ? ' ▲' : pnl < 0 ? ' ▼' : ''),
      round.trades.length + (round.trades.length === 1 ? ' trade' : ' trades') + (liqs ? ' · ' + liqs + ' liquidation' + (liqs > 1 ? 's' : '') : ''),
      window.location.origin + window.location.pathname,
    ];
    try {
      await navigator.clipboard.writeText(lines.join('\n'));
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className={'card p-5 text-center ' + (won ? 'card-up' : pnl < 0 ? 'card-down' : '')}>
        <p className="text-xs font-extrabold uppercase tracking-wide text-muted">Round P&L</p>
        <p className={'text-6xl font-black tabular ' + (won ? 'text-up' : pnl < 0 ? 'text-coral' : '')}>{fmtSigned(pnl)}</p>
        <p className="mt-1 text-sm font-bold text-muted">
          {round.trades.length === 0 ? 'You sat this one out.' : round.trades.length + (round.trades.length === 1 ? ' trade' : ' trades') + (liqs ? ' · ' + liqs + ' liquidated' : '') + ' · ended with ' + fmtCredits(round.finalValue ?? 0)}
        </p>
        {ghost && (
          <div className="mt-3 inline-flex flex-wrap items-center justify-center gap-x-3 gap-y-1 rounded-full border-2 border-line bg-paper px-4 py-1.5 text-sm font-extrabold">
            <span>You {fmtSigned(pnl)}</span>
            <span className="text-muted">vs</span>
            <span>
              {ghost.name} {fmtSigned(ghost.pnl)}
            </span>
            <span className={pnl > ghost.pnl ? 'text-up' : pnl < ghost.pnl ? 'text-coral' : 'text-muted'}>{pnl > ghost.pnl ? '· you take it' : pnl < ghost.pnl ? '· ghost takes it' : '· tie'}</span>
          </div>
        )}
      </div>

      {extra}

      <div className="card overflow-hidden">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 px-4 pt-3 text-xs font-extrabold">
          <span className="flex items-center gap-1">
            <i className="inline-block h-1 w-5 rounded bg-ink" /> What you traded
          </span>
          <span className="flex items-center gap-1 text-true">
            <i className="inline-block h-0 w-5 border-t-2 border-dashed border-true" /> True curve (no bots)
          </span>
          {ghost && (
            <span className="flex items-center gap-1 text-ghost">
              <i className="inline-block h-2.5 w-2.5 rounded-full bg-ghost" /> {ghost.name}
            </span>
          )}
        </div>
        <Chart prices={round.prices} truePrices={round.truePrices ?? null} totalTicks={round.totalTicks} secondsPerTick={round.tickMs / 1000} headProgress={1} live={false} markers={markers} height={260} />
      </div>

      {round.trades.length > 0 && (
        <div className="card divide-y-2 divide-line">
          {round.trades.map((t, i) => (
            <div key={i} className="flex items-center justify-between px-4 py-2 text-sm">
              <span className="font-bold">
                <span className={t.side === 'long' ? 'text-up' : 'text-coral'}>{t.side === 'long' ? 'Long' : 'Short'}</span> {t.lev}x · {fmtCredits(t.margin)} @ {fmtPrice(t.entryPrice)} → {t.kind === 'liquidated' ? 'liquidated' : fmtPrice(t.exitPrice)}
              </span>
              <span className={'font-black tabular ' + (t.pnl >= 0 ? 'text-up' : 'text-coral')}>{fmtSigned(t.pnl)}</span>
            </div>
          ))}
        </div>
      )}

      <div className="flex gap-2">
        <button type="button" className="btn btn-ghost flex-1" onClick={() => void share()}>
          {copied ? 'Copied!' : 'Copy result'}
        </button>
        {children}
      </div>

      {r && (
        <div className="card p-4">
          <p className="text-xs font-extrabold uppercase tracking-wide text-brand">Behind the chart</p>
          <p className="mt-1 text-sm font-bold text-muted">
            <span className="rounded bg-paper px-1.5 py-0.5 font-extrabold uppercase text-ink">Simulated</span> This round was a simulated match: a hidden {'"'}true{'"'} win-chance curve plus six blind AI traders pushing the price around. No real teams. Real chess games are coming as the first real data pack.
          </p>
          <p className="mt-1 text-xs font-bold text-muted">{r.windowText.replace('Price = chance ' + r.sideA + ' wins × 100.', '')}</p>
        </div>
      )}
    </div>
  );
}

export type { Side };
