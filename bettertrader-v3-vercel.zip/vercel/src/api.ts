// Tiny fetch client. Resolves with { data } like axios; rejects on network failure.
async function call(method: string, url: string, body?: unknown): Promise<{ data: unknown }> {
  const res = await fetch(url, {
    method,
    headers: body !== undefined ? { 'content-type': 'application/json' } : undefined,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  let data: unknown = null;
  try {
    data = await res.json();
  } catch {
    data = null;
  }
  if (!res.ok && (!data || typeof (data as { error?: unknown }).error !== 'string')) {
    throw new Error('Request failed with status ' + res.status);
  }
  return { data };
}

export const api = {
  get: (url: string) => call('GET', url),
  post: (url: string, body?: unknown) => call('POST', url, body ?? {}),
  put: (url: string, body?: unknown) => call('PUT', url, body ?? {}),
  delete: (url: string, body?: unknown) => call('DELETE', url, body),
};
