import { useCallback, useEffect, useState } from 'react';
import { api } from './api';
import RoundPlay from './RoundPlay';
import { SPEED, errorMessage, fmtCountdown, fmtDateLong, fmtSigned, unwrap, type DailyInfo, type Player, type RoundState } from './lib';

interface Props {
  player: Player;
  onPlayerChanged: () => void;
}

export default function DailyTab({ player, onPlayerChanged }: Props) {
  const [info, setInfo] = useState<DailyInfo | null>(null);
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [reviewing, setReviewing] = useState(false);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const [now, setNow] = useState(Date.now());

  const load = useCallback(async () => {
    try {
      const d = unwrap<DailyInfo>(await api.get('/api/daily?playerId=' + encodeURIComponent(player.playerId)));
      setInfo(d);
      if (d.played && !d.settled && d.roundId) {
        setPlayingId(d.roundId);
      }
    } catch (err) {
      setMsg(errorMessage(err, "Could not load today's mystery."));
    }
  }, [player.playerId]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(t);
  }, []);

  const start = async (): Promise<void> => {
    if (busy) {
      return;
    }
    setBusy(true);
    setMsg('');
    try {
      const r = unwrap<RoundState>(await api.post('/api/daily/start', { playerId: player.playerId, speed: SPEED }));
      setPlayingId(r.roundId);
    } catch (err) {
      setMsg(errorMessage(err, 'Could not start. Try again.'));
    } finally {
      setBusy(false);
    }
  };

  const onEnded = useCallback(() => {
    setReviewing(true);
    onPlayerChanged();
    void load();
  }, [onPlayerChanged, load]);

  if (playingId && (reviewing || !info || !info.settled)) {
    return (
      <RoundPlay
        roundId={playingId}
        playerId={player.playerId}
        shareLabel={'Daily · ' + (info ? fmtDateLong(info.date) : '')}
        onEnded={onEnded}
        header={
          <div className="flex items-center justify-between px-1">
            <h2 className="text-lg font-black">Today's Mystery</h2>
            <span className="text-xs font-extrabold uppercase tracking-wide text-muted">One shot · same match for everyone</span>
          </div>
        }
        revealActions={() => (
          <button
            type="button"
            className="btn btn-primary flex-1"
            onClick={() => {
              setPlayingId(null);
              setReviewing(false);
              void load();
            }}
          >
            See leaderboard
          </button>
        )}
      />
    );
  }

  if (!info) {
    return (
      <div className="card p-6 text-center">
        <p className="font-extrabold">Loading today's mystery…</p>
        {msg && <p className="mt-2 text-sm font-bold text-coral">{msg}</p>}
      </div>
    );
  }

  const resetIn = Math.max(0, (info.resetsAt - (now + (info.serverNow - Date.now()))) / 1000);
  const myRank = info.board.findIndex(b => b.playerId === player.playerId);

  return (
    <div className="space-y-3">
      {!info.played ? (
        <div className="card hero p-6">
          <p className="text-xs font-extrabold uppercase tracking-wide text-brand">Daily Mystery · {fmtDateLong(info.date)}</p>
          <h2 className="mt-1 text-3xl font-black leading-tight">One match. One shot. Most money wins.</h2>
          <p className="mt-2 font-bold text-muted">Everyone gets the exact same chart, same clock, one try. No second chances, no tips from friends — just who reads it best.</p>
          <button type="button" className="btn btn-primary mt-4 w-full text-lg" disabled={busy} onClick={() => void start()}>
            Play today's mystery
          </button>
          {msg && <p className="mt-2 text-sm font-bold text-coral">{msg}</p>}
          <p className="mt-3 text-xs font-bold text-muted">
            {info.players} {info.players === 1 ? 'trader has' : 'traders have'} played · resets in {fmtCountdown(resetIn)}
          </p>
        </div>
      ) : (
        <div className={'card p-5 text-center ' + ((info.pnl ?? 0) > 0 ? 'card-up' : (info.pnl ?? 0) < 0 ? 'card-down' : '')}>
          <p className="text-xs font-extrabold uppercase tracking-wide text-muted">Played today · {fmtDateLong(info.date)}</p>
          <p className={'text-5xl font-black tabular ' + ((info.pnl ?? 0) > 0 ? 'text-up' : (info.pnl ?? 0) < 0 ? 'text-coral' : '')}>{fmtSigned(info.pnl ?? 0)}</p>
          <p className="mt-1 text-sm font-bold text-muted">
            {myRank >= 0 ? 'Rank #' + (myRank + 1) + ' of ' + info.players : info.players + ' played'} · next mystery in {fmtCountdown(resetIn)}
          </p>
          {info.roundId && (
            <button
              type="button"
              className="btn btn-ghost mt-3"
              onClick={() => {
                setReviewing(true);
                setPlayingId(info.roundId);
              }}
            >
              Review the reveal
            </button>
          )}
        </div>
      )}

      <div className="grid grid-cols-2 gap-2">
        <div className="card px-4 py-3">
          <p className="text-[11px] font-extrabold uppercase tracking-wide text-muted">Streak</p>
          <p className="text-2xl font-black tabular">
            {info.streak} {info.streak === 1 ? 'day' : 'days'}
          </p>
        </div>
        <div className="card px-4 py-3">
          <p className="text-[11px] font-extrabold uppercase tracking-wide text-muted">Lifetime P&L</p>
          <p className={'text-2xl font-black tabular ' + (player.lifetimePnl > 0 ? 'text-up' : player.lifetimePnl < 0 ? 'text-coral' : '')}>{fmtSigned(player.lifetimePnl)}</p>
        </div>
      </div>

      <div className="card">
        <div className="flex items-center justify-between px-4 py-3">
          <h3 className="font-black">Today's leaderboard</h3>
          <span className="text-xs font-extrabold text-muted">{info.players} played</span>
        </div>
        {info.board.length === 0 ? (
          <p className="border-t-2 border-line px-4 py-6 text-center text-sm font-bold text-muted">Nobody has finished yet. Be the first name here.</p>
        ) : (
          <ol className="divide-y-2 divide-line border-t-2 border-line">
            {info.board.map((b, i) => (
              <li key={b.playerId} className={'flex items-center gap-3 px-4 py-2 ' + (b.playerId === player.playerId ? 'bg-brand/10' : '')}>
                <span className="w-6 text-sm font-black text-muted">{i + 1}</span>
                <span className="flex-1 truncate font-bold">
                  {b.name}
                  {b.playerId === player.playerId ? ' (you)' : ''}
                </span>
                <span className={'font-black tabular ' + (b.pnl > 0 ? 'text-up' : b.pnl < 0 ? 'text-coral' : '')}>{fmtSigned(b.pnl)}</span>
              </li>
            ))}
          </ol>
        )}
      </div>
    </div>
  );
}
