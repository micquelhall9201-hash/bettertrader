import { useCallback, useEffect, useState } from 'react';
import { api } from './api';
import DailyTab from './DailyTab';
import DuelTab from './DuelTab';
import LiveTab from './LiveTab';
import ProfileTab from './ProfileTab';
import { isMuted, setMuted, sfx } from './sound';
import { ensurePlayer, errorMessage, unwrap, type Player } from './lib';

type Tab = 'daily' | 'live' | 'duel' | 'me';

const TABS: Array<{ id: Tab; label: string; icon: string }> = [
  { id: 'daily', label: 'Daily', icon: '◆' },
  { id: 'live', label: 'Live', icon: '●' },
  { id: 'duel', label: 'Duel', icon: '⚔' },
  { id: 'me', label: 'Me', icon: '▲' },
];

const INTRO_KEY = 'bettertrader-intro-done';

const INTRO = [
  {
    title: 'One line. Up or down.',
    body: 'The chart is the live odds of a hidden match, 0 to 100. Think it goes up? Go LONG. Down? Go SHORT. Close whenever you want.',
    accent: 'text-brand',
  },
  {
    title: 'Leverage is the gas pedal.',
    body: '5x means every point the chart moves is worth 5x your stake per point. Move too far the wrong way and you get LIQUIDATED — that stake is gone.',
    accent: 'text-coral',
  },
  {
    title: 'Most money wins.',
    body: 'Same chart, same clock as everyone else in the room. Green glow means you lead. Red means catch up. Nobody knows when the round ends.',
    accent: 'text-up',
  },
];

function App() {
  const [player, setPlayer] = useState<Player | null>(null);
  const [tab, setTab] = useState<Tab>(() => {
    if (new URLSearchParams(window.location.search).get('room')) {
      return 'live';
    }
    const saved = window.localStorage.getItem('bettertrader-tab');
    return saved === 'duel' || saved === 'me' || saved === 'live' ? saved : 'daily';
  });
  const [err, setErr] = useState('');
  const [intro, setIntro] = useState(() => (window.localStorage.getItem(INTRO_KEY) ? -1 : 0));
  const [muted, setMutedState] = useState(isMuted());

  useEffect(() => {
    ensurePlayer()
      .then(setPlayer)
      .catch(e => setErr(errorMessage(e, 'Could not reach the server. Refresh to try again.')));
  }, []);

  const refreshPlayer = useCallback(() => {
    if (!player) {
      return;
    }
    api
      .get('/api/players/' + encodeURIComponent(player.playerId))
      .then(res => setPlayer(unwrap<Player>(res)))
      .catch(() => undefined);
  }, [player]);

  const switchTab = (t: Tab): void => {
    setTab(t);
    sfx.tick();
    window.localStorage.setItem('bettertrader-tab', t);
  };

  const toggleMute = (): void => {
    const m = !muted;
    setMuted(m);
    setMutedState(m);
    if (!m) {
      sfx.open();
    }
  };

  const nextIntro = (): void => {
    sfx.tick();
    if (intro >= INTRO.length - 1) {
      window.localStorage.setItem(INTRO_KEY, '1');
      setIntro(-1);
    } else {
      setIntro(intro + 1);
    }
  };

  return (
    <div className="min-h-screen bg-paper text-ink">
      <header className="sticky top-0 z-10 border-b-2 border-line bg-paper/95 backdrop-blur">
        <div className="mx-auto flex max-w-2xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="logo">BT</span>
            <span className="text-xl font-black tracking-tight">BetterTrader</span>
          </div>
          <div className="flex items-center gap-3">
            {player && (
              <div className="text-right">
                <p className="text-sm font-black leading-tight">{player.name}</p>
                <p className="text-[11px] font-extrabold uppercase tracking-wide text-muted">rating {player.rating}</p>
              </div>
            )}
            <button type="button" className="chip px-2" onClick={toggleMute} aria-label={muted ? 'Unmute sounds' : 'Mute sounds'}>
              {muted ? '🔇' : '🔊'}
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-2xl px-4 pb-28 pt-4">
        {err ? (
          <div className="card p-6 text-center">
            <p className="font-extrabold text-coral">{err}</p>
          </div>
        ) : !player ? (
          <div className="card p-6 text-center font-extrabold">Setting up your trader…</div>
        ) : tab === 'daily' ? (
          <DailyTab player={player} onPlayerChanged={refreshPlayer} />
        ) : tab === 'live' ? (
          <LiveTab player={player} onPlayerChanged={refreshPlayer} />
        ) : tab === 'duel' ? (
          <DuelTab player={player} onPlayerChanged={refreshPlayer} />
        ) : (
          <ProfileTab key={player.name} player={player} onPlayerChanged={refreshPlayer} />
        )}
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-10 border-t-2 border-line bg-paper" aria-label="Main">
        <div className="mx-auto grid max-w-2xl grid-cols-4">
          {TABS.map(t => (
            <button key={t.id} type="button" onClick={() => switchTab(t.id)} className={'tab ' + (tab === t.id ? 'tab-active' : '')} aria-current={tab === t.id ? 'page' : undefined}>
              <span className="text-lg leading-none" aria-hidden>
                {t.icon}
              </span>
              <span>{t.label}</span>
            </button>
          ))}
        </div>
      </nav>

      {intro >= 0 && player && (
        <div className="overlay" role="dialog" aria-modal="true" aria-label="How to play">
          <div className="card w-full max-w-sm p-6">
            <p className="text-xs font-extrabold uppercase tracking-wide text-muted">
              {intro + 1} of {INTRO.length}
            </p>
            <h2 className={'mt-1 text-3xl font-black leading-tight ' + INTRO[intro].accent}>{INTRO[intro].title}</h2>
            <p className="mt-3 font-bold text-muted">{INTRO[intro].body}</p>
            <button type="button" className="btn btn-primary mt-5 w-full text-lg" onClick={nextIntro}>
              {intro >= INTRO.length - 1 ? "Let's trade" : 'Next'}
            </button>
            {intro < INTRO.length - 1 && (
              <button
                type="button"
                className="mt-2 w-full text-center text-xs font-bold text-muted"
                onClick={() => {
                  window.localStorage.setItem(INTRO_KEY, '1');
                  setIntro(-1);
                }}
              >
                Skip
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
