# BetterTrader

Fast chart-trading game. Vite + React frontend, Vercel serverless API (`api/`), Postgres (Neon) storage.

## Deploy (Vercel)
1. Push this folder to a GitHub repo.
2. Vercel → Add New → Project → import the repo → Deploy (defaults are fine; framework: Vite).
3. Vercel project → Storage → Create Database → **Neon (Postgres)** → connect to this project (all environments).
4. Deployments → Redeploy. The API creates its table on first request.

`DATABASE_URL` (or `POSTGRES_URL`) is the only setting the app needs.

## Local
`npm i && DATABASE_URL=postgres://... npx vercel dev` (or `npm run dev` with an API running on :3000).
