/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        paper: '#050604',
        panel: '#15201b',
        line: '#2c3a33',
        ink: '#f4efe4',
        muted: '#a7b0a8',
        brand: { DEFAULT: '#e8b64c', dark: '#6a4600' },
        up: '#2f8f63',
        coral: '#e40000',
        true: '#5b8cff',
        ghost: '#c084fc',
      },
      fontFamily: {
        sans: ['Manrope', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        display: ['"DM Serif Display"', 'Georgia', 'serif'],
      },
    },
  },
  plugins: [],
};
