import { router, json, error, db, increment } from './_sdk';

// ---------- constants ----------

const PLAYERS = 'players';
const ROUNDS = 'rounds';
const DUELS = 'duels';
const ROOMS = 'rooms';
const OPEN_ROOMS = 'openrooms';
const DAILY_PLAYS = 'dailyplays';
const ROUND_CASH = 1000;
const BASE_TICKS = 400;
const PRE_ROUND_MS = 4000;
const TICK_MS = 1000;
const FAST_TICK_MS = 300;
const MAX_DEV = 0.12;
const ENGINE = 'BetterTrader synthetic engine v2';
const DAILY_SALT = 'bt-daily-2027g-v2';
const BEST_OF = 3;
const MAX_DUEL_ROUNDS = 5;
const LEVERAGES = [1, 2, 5, 10, 20];
const MAX_ROOM = 8;

type Side = 'long' | 'short';
type Mode = 'daily' | 'duel' | 'practice' | 'live';
type Pace = 'blitz' | 'standard';
type TickStatus = 'pending' | 'live' | 'ended';

interface Position {
  side: Side;
  margin: number;
  lev: number;
  entryPrice: number;
  qty: number;
  entryTick: number;
  liqPrice: number;
}

interface Trade {
  side: Side;
  margin: number;
  lev: number;
  entryPrice: number;
  exitPrice: number;
  entryTick: number;
  exitTick: number;
  pnl: number;
  kind: 'close' | 'liquidated' | 'settled';
}

interface BotAction {
  t: number;
  bot: string;
  side: 'buy' | 'sell' | 'warn';
  size: number;
}

interface Reveal {
  label: string;
  sideA: string;
  sideB: string;
  competition: string;
  winner: string;
  windowText: string;
  generator: string;
  seed: number;
  note: string;
}

interface Ghost {
  name: string;
  style: string;
  blurb: string;
  trades: Trade[];
  pnl: number;
}

interface RoundRecord {
  playerId: string;
  mode: Mode;
  pace: Pace;
  duelId: string | null;
  roomCode: string | null;
  dailyDate: string | null;
  seed: number;
  tickMs: number;
  ticks: number;
  startTs: number;
  createdAt: number;
  trueSeries: number[];
  market: number[];
  botLog: BotAction[];
  reveal: Reveal;
  cash: number;
  pos: Position | null;
  trades: Trade[];
  settled: boolean;
  finalValue: number | null;
  pnl: number | null;
  ghost: Ghost | null;
  endedEarly?: boolean;
}

interface PlayerRecord {
  name: string;
  rating: number;
  lifetimePnl: number;
  roundsPlayed: number;
  duelsWon: number;
  duelsLost: number;
  liveWins: number;
  liquidations: number;
  bestRound: number;
  dailyStreak: number;
  lastDailyDate: string | null;
  createdAt: number;
}

interface DuelResult {
  roundId: string;
  playerPnl: number;
  ghostPnl: number;
  winner: 'you' | 'ghost' | 'tie';
}

interface DuelRecord {
  playerId: string;
  ghostName: string;
  ghostStyle: string;
  ghostBlurb: string;
  pace: Pace;
  roundIds: string[];
  results: DuelResult[];
  playerWins: number;
  ghostWins: number;
  status: 'live' | 'won' | 'lost' | 'draw';
  ratingDelta: number;
  createdAt: number;
}

interface RoomPlayer {
  id: string;
  name: string;
  bot?: string;
}

interface RoomRecord {
  code: string;
  hostId: string;
  pace: Pace;
  isPublic: boolean;
  players: RoomPlayer[];
  status: 'lobby' | 'live' | 'ended';
  seed: number | null;
  ticks: number | null;
  startTs: number | null;
  tickMs: number;
  roundIds: Record<string, string>;
  createdAt: number;
  startedAt: number | null;
  resultsAwarded: boolean;
  nextCode: string | null;
}

interface DailyPlay {
  playerId: string;
  date: string;
  roundId: string;
  pnl: number | null;
  settled: boolean;
}

// ---------- helpers ----------

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

function round4(n: number): number {
  return Math.round(n * 10000) / 10000;
}

function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n));
}

function asString(v: unknown): string {
  return typeof v === 'string' ? v.trim() : '';
}

function secureSeed(): number {
  const g = globalThis as {
    crypto?: { getRandomValues?: (arr: Uint32Array) => Uint32Array };
  };
  if (g.crypto && typeof g.crypto.getRandomValues === 'function') {
    const buf = new Uint32Array(1);
    g.crypto.getRandomValues(buf);
    return buf[0] >>> 1;
  }
  return Math.floor(Math.random() * 2147483647);
}

function hashString(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) >>> 1;
}

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function gaussian(rng: () => number): number {
  const u = Math.max(rng(), 1e-9);
  const v = rng();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

function utcDate(now: number): string {
  return new Date(now).toISOString().slice(0, 10);
}

function nextUtcMidnight(now: number): number {
  const d = new Date(now);
  return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + 1);
}

function prevDate(date: string): string {
  const d = new Date(date + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() - 1);
  return d.toISOString().slice(0, 10);
}

function paceFrom(v: unknown): Pace {
  return asString(v) === 'blitz' ? 'blitz' : 'standard';
}

function fastFrom(v: unknown): boolean {
  return asString(v) === 'fast';
}

function ticksFor(pace: Pace, rng: () => number): number {
  return pace === 'blitz' ? 20 + Math.floor(rng() * 21) : 60 + Math.floor(rng() * 91);
}

function makeHandle(): string {
  const words = ['Bull', 'Bear', 'Whale', 'Pixel', 'Rocket', 'Comet', 'Dash', 'Nova', 'Turbo', 'Spark'];
  const w = words[Math.floor(Math.random() * words.length)];
  const n = 100 + Math.floor(Math.random() * 900);
  return w + n;
}

function makeCode(): string {
  const letters = 'ABCDEFGHJKMNPQRSTUVWXYZ';
  let s = '';
  for (let i = 0; i < 4; i++) {
    s += letters[Math.floor(Math.random() * letters.length)];
  }
  return s;
}


// ---------- synthetic hidden match (clearly labeled fictional) ----------

const CLUBS = [
  'Harbor Gulls',
  'Ridgeline Foxes',
  'Saltmarsh Otters',
  'Copperfield Hawks',
  'Northgate Lynx',
  'Tidewater Herons',
  'Ironwood Bears',
  'Lantern Hill Owls',
  'Greyrock Wolves',
  'Meridian Stags',
  'Kestrel Bay',
  'Dunmore Rooks',
];

function generateBase(seed: number): { series: number[]; outcome: 0 | 1 } {
  const rng = mulberry32(seed);
  const outcome: 0 | 1 = rng() < 0.5 ? 1 : 0;
  const logit = (p: number): number => Math.log(p / (1 - p));
  const sigmoid = (x: number): number => 1 / (1 + Math.exp(-x));
  let x = logit(0.3 + rng() * 0.4);
  const target = outcome === 1 ? 2.2 : -2.2;
  const vol = 0.2 + rng() * 0.16;
  const series: number[] = [];
  let regime = 0;
  for (let i = 0; i < BASE_TICKS; i++) {
    if (i > 0) {
      const t = i / (BASE_TICKS - 1);
      const pull = (target - x) * (0.002 + 0.05 * t * t * t);
      if (rng() < 0.03) {
        regime = (rng() - 0.5) * 0.25;
      }
      regime *= 0.97;
      let jump = 0;
      if (rng() < 0.06) {
        const towardOutcome = rng() < 0.55 + 0.3 * t;
        const direction = towardOutcome ? Math.sign(target) : -Math.sign(target);
        jump = (0.5 + rng() * 1.3) * direction;
      }
      x = clamp(x + pull + regime + gaussian(rng) * vol + jump, -2.4, 2.4);
    }
    series.push(clamp(round4(sigmoid(x)), 0.06, 0.94));
  }
  return { series, outcome };
}

function buildReveal(seed: number, outcome: 0 | 1, start: number, len: number): Reveal {
  const rng = mulberry32(seed ^ 0x5bd1e995);
  const a = Math.floor(rng() * CLUBS.length);
  let b = Math.floor(rng() * (CLUBS.length - 1));
  if (b >= a) {
    b += 1;
  }
  const season = 1 + Math.floor(rng() * 5);
  const matchday = 1 + Math.floor(rng() * 30);
  const sideA = CLUBS[a];
  const sideB = CLUBS[b];
  const minuteStart = Math.round((start / BASE_TICKS) * 90);
  const minuteEnd = Math.round(((start + len) / BASE_TICKS) * 90);
  return {
    label: 'Synthetic',
    sideA,
    sideB,
    competition: 'Synthetic League · Season ' + season + ' · Matchday ' + matchday,
    winner: outcome === 1 ? sideA : sideB,
    windowText: 'You traded minutes ' + minuteStart + '–' + minuteEnd + ' of the match. Price = chance ' + sideA + ' wins × 100.',
    generator: ENGINE,
    seed,
    note: 'Fictional fixture. No real match, team or market exists behind this chart. It was generated for this round.',
  };
}

// ---------- bot traders (blind: they only see the past) ----------

const BOTS = [
  { id: 'momo', name: 'MOMO', style: 'Momentum', blurb: 'Buys strength, sells weakness' },
  { id: 'dippy', name: 'DIPPY', style: 'Dip buyer', blurb: 'Buys every drop' },
  { id: 'panic', name: 'PANIC', style: 'Panic seller', blurb: 'Dumps on red' },
  { id: 'whale', name: 'WHALE', style: 'Whale', blurb: 'Big random splashes' },
  { id: 'fader', name: 'FADER', style: 'Mean reverter', blurb: 'Sells spikes, buys dips' },
  { id: 'sniper', name: 'SNIPER', style: 'Sniper', blurb: 'Rare, huge, one-way' },
];

function sizeOf(push: number): number {
  const a = Math.abs(push);
  return a > 0.035 ? 3 : a > 0.016 ? 2 : 1;
}

function simulateMarket(seed: number, trueSeries: number[]): { market: number[]; botLog: BotAction[] } {
  const rng = mulberry32(seed ^ 0x9e3779b9);
  const n = trueSeries.length;
  const market: number[] = [trueSeries[0]];
  const botLog: BotAction[] = [];
  let offset = 0;
  let pendingSniper = 0;
  const log = (t: number, bot: string, push: number): void => {
    botLog.push({ t, bot, side: push > 0 ? 'buy' : 'sell', size: sizeOf(push) });
  };
  for (let t = 1; t < n; t++) {
    const prev = market[t - 1];
    const prev2 = t >= 2 ? market[t - 2] : prev;
    const d = prev - prev2;
    let push = 0;
    if (Math.abs(d) > 0.008 && rng() < 0.65) {
      const s = Math.sign(d) * 0.018 * (0.5 + rng());
      push += s;
      log(t, 'momo', s);
    }
    if (d < -0.015 && rng() < 0.7) {
      const s = 0.02 * (0.5 + rng());
      push += s;
      log(t, 'dippy', s);
    }
    if (d < -0.025 && rng() < 0.65) {
      const s = -0.022 * (0.5 + rng());
      push += s;
      log(t, 'panic', s);
    }
    if (rng() < 0.08) {
      const s = (rng() < 0.5 ? -1 : 1) * 0.04 * (0.5 + rng());
      push += s;
      log(t, 'whale', s);
    }
    if (pendingSniper !== 0) {
      push += pendingSniper;
      log(t, 'sniper', pendingSniper);
      pendingSniper = 0;
    } else if (rng() < 0.02 && t < n - 2) {
      pendingSniper = (rng() < 0.5 ? -1 : 1) * 0.08 * (0.6 + rng());
      botLog.push({ t, bot: 'sniper', side: 'warn', size: 3 });
    }
    if (t >= 5) {
      let sum = 0;
      for (let k = t - 5; k < t; k++) {
        sum += market[k];
      }
      const dev = prev - sum / 5;
      if (Math.abs(dev) > 0.025 && rng() < 0.7) {
        const s = -Math.sign(dev) * 0.016 * (0.5 + rng());
        push += s;
        log(t, 'fader', s);
      }
    }
    offset = clamp(offset * 0.75 + push, -MAX_DEV, MAX_DEV);
    market.push(clamp(round4(trueSeries[t] + offset), 0.04, 0.96));
  }
  return { market, botLog };
}

function priceAt(market: number[], t: number): number {
  return round2(market[Math.min(t, market.length - 1)] * 100);
}

// ---------- positions ----------

function liqPriceFor(side: Side, entry: number, lev: number): number {
  return side === 'long' ? round2(entry * (1 - 1 / lev)) : round2(entry * (1 + 1 / lev));
}

function unrealized(pos: Position, price: number): number {
  const raw = pos.side === 'long' ? pos.qty * (price - pos.entryPrice) : pos.qty * (pos.entryPrice - price);
  return round2(Math.max(raw, -pos.margin));
}

function liquidatedAt(pos: Position, market: number[], upToTick: number): number | null {
  for (let t = pos.entryTick + 1; t <= Math.min(upToTick, market.length - 1); t++) {
    const p = priceAt(market, t);
    if (pos.side === 'long' ? p <= pos.liqPrice : p >= pos.liqPrice) {
      return t;
    }
  }
  return null;
}

// ---------- ghost opponents for duels (blind, causal strategies) ----------

const GHOSTS = [
  { name: 'Trendy', style: 'TREND', blurb: 'Rides momentum at 5x, bails at ±25%' },
  { name: 'Scalps', style: 'SCALPER', blurb: 'Quick 10x stabs, out in 6 seconds' },
  { name: 'Yolo', style: 'YOLO', blurb: 'All-in 20x against the crowd' },
];

function runGhost(style: string, market: number[], ticks: number): { trades: Trade[]; pnl: number } {
  const st: { cash: number; pos: Position | null } = { cash: ROUND_CASH, pos: null };
  const trades: Trade[] = [];
  const open = (t: number, side: Side, margin: number, lev: number): void => {
    if (st.pos || margin < 1 || margin > st.cash) {
      return;
    }
    const entry = priceAt(market, t);
    st.pos = { side, margin: round2(margin), lev, entryPrice: entry, qty: round4((margin * lev) / entry), entryTick: t, liqPrice: liqPriceFor(side, entry, lev) };
    st.cash = round2(st.cash - margin);
  };
  const close = (t: number, kind: Trade['kind']): void => {
    const pos = st.pos;
    if (!pos) {
      return;
    }
    const exit = kind === 'liquidated' ? pos.liqPrice : priceAt(market, t);
    const pnl = kind === 'liquidated' ? -pos.margin : unrealized(pos, exit);
    trades.push({ side: pos.side, margin: pos.margin, lev: pos.lev, entryPrice: pos.entryPrice, exitPrice: exit, entryTick: pos.entryTick, exitTick: t, pnl, kind });
    st.cash = round2(st.cash + pos.margin + pnl);
    st.pos = null;
  };
  for (let t = 1; t < ticks; t++) {
    const pos = st.pos;
    if (pos) {
      const p = priceAt(market, t);
      if (pos.side === 'long' ? p <= pos.liqPrice : p >= pos.liqPrice) {
        close(t, 'liquidated');
        continue;
      }
    }
    const p = priceAt(market, t);
    if (style === 'TREND') {
      if (!pos && t >= 4 && t % 6 === 0) {
        const d = p - priceAt(market, t - 4);
        if (Math.abs(d) > 1.5) {
          open(t, d > 0 ? 'long' : 'short', Math.min(400, st.cash), 5);
        }
      } else if (pos) {
        const r = unrealized(pos, p) / pos.margin;
        if (r >= 0.25 || r <= -0.25) {
          close(t, 'close');
        }
      }
    } else if (style === 'SCALPER') {
      if (!pos && t % 9 === 0) {
        const d = p - priceAt(market, t - 2);
        if (Math.abs(d) > 0.8) {
          open(t, d > 0 ? 'long' : 'short', Math.min(200, st.cash), 10);
        }
      } else if (pos && t - pos.entryTick >= 6) {
        close(t, 'close');
      }
    } else if (style === 'YOLO') {
      if (!pos && t === Math.max(3, Math.floor(ticks * 0.25))) {
        const d = p - priceAt(market, 0);
        open(t, d > 0 ? 'short' : 'long', st.cash, 20);
      }
    }
  }
  if (st.pos) {
    close(ticks - 1, 'settled');
  }
  return { trades, pnl: round2(st.cash - ROUND_CASH) };
}

function ghostEquityAt(ghost: Ghost, market: number[], tick: number): number {
  let cash = ROUND_CASH;
  for (const t of ghost.trades) {
    if (t.exitTick <= tick) {
      cash += t.pnl;
    } else if (t.entryTick <= tick) {
      const pos: Position = { side: t.side, margin: t.margin, lev: t.lev, entryPrice: t.entryPrice, qty: round4((t.margin * t.lev) / t.entryPrice), entryTick: t.entryTick, liqPrice: liqPriceFor(t.side, t.entryPrice, t.lev) };
      cash += unrealized(pos, priceAt(market, tick));
    }
  }
  return round2(cash);
}

// ---------- db access ----------

async function getRound(id: string): Promise<RoundRecord | null> {
  const [r] = await db.get<RoundRecord>(ROUNDS, [id], { consistent: true });
  return r ?? null;
}

async function getPlayer(id: string): Promise<PlayerRecord | null> {
  const [p] = await db.get<PlayerRecord>(PLAYERS, [id], { consistent: true });
  return p ?? null;
}

async function getDuel(id: string): Promise<DuelRecord | null> {
  const [d] = await db.get<DuelRecord>(DUELS, [id], { consistent: true });
  return d ?? null;
}

async function getRoom(code: string): Promise<RoomRecord | null> {
  const [r] = await db.get<RoomRecord>(ROOMS, [code], { consistent: true });
  return r ?? null;
}

function publicPlayer(id: string, p: PlayerRecord): Record<string, unknown> {
  return {
    playerId: id,
    name: p.name,
    rating: p.rating,
    lifetimePnl: round2(p.lifetimePnl),
    roundsPlayed: p.roundsPlayed,
    duelsWon: p.duelsWon,
    duelsLost: p.duelsLost,
    liveWins: p.liveWins ?? 0,
    liquidations: p.liquidations ?? 0,
    bestRound: round2(p.bestRound ?? 0),
    dailyStreak: p.dailyStreak,
    lastDailyDate: p.lastDailyDate,
  };
}

// ---------- round lifecycle ----------

function tickState(r: RoundRecord, now: number): { status: TickStatus; tick: number } {
  if (r.endedEarly) {
    return { status: 'ended', tick: r.ticks - 1 };
  }
  if (now < r.startTs) {
    return { status: 'pending', tick: -1 };
  }
  const k = Math.floor((now - r.startTs) / r.tickMs);
  if (k >= r.ticks - 1) {
    return { status: 'ended', tick: r.ticks - 1 };
  }
  return { status: 'live', tick: k };
}

interface CreateOpts {
  mode: Mode;
  pace: Pace;
  fast: boolean;
  seed?: number;
  ticks?: number;
  startTs?: number;
  offsetSeed?: number;
  duelId?: string;
  roomCode?: string;
  dailyDate?: string;
  ghost?: { name: string; style: string; blurb: string };
}

function buildSeries(seed: number, pace: Pace, ticksOverride?: number, offsetSeed?: number): {
  trueSeries: number[];
  market: number[];
  botLog: BotAction[];
  ticks: number;
  reveal: Reveal;
} {
  const base = generateBase(seed);
  const rng = mulberry32(seed ^ 0x2545f491);
  const ticks = ticksOverride ?? ticksFor(pace, rng);
  const maxStart = BASE_TICKS - ticks - 2;
  let start = 10 + Math.floor(rng() * (maxStart - 10));
  for (let tries = 0; tries < 24; tries++) {
    const p0 = base.series[start];
    const pMid = base.series[Math.min(start + Math.floor(ticks / 2), BASE_TICKS - 1)];
    if (p0 > 0.2 && p0 < 0.8 && pMid > 0.12 && pMid < 0.88) {
      break;
    }
    start = 10 + Math.floor(rng() * (maxStart - 10));
  }
  if (offsetSeed !== undefined) {
    const orng = mulberry32(offsetSeed);
    start = clamp(start + Math.floor(orng() * 16) - 8, 2, maxStart);
  }
  const trueSeries = base.series.slice(start, start + ticks);
  const sim = simulateMarket(seed + (offsetSeed ?? 0), trueSeries);
  return { trueSeries, market: sim.market, botLog: sim.botLog, ticks, reveal: buildReveal(seed, base.outcome, start, ticks) };
}

async function createRound(playerId: string, opts: CreateOpts): Promise<{ id: string; record: RoundRecord }> {
  const seed = opts.seed ?? secureSeed();
  const createdAt = Date.now();
  const built = buildSeries(seed, opts.pace, opts.ticks, opts.offsetSeed);
  let ghost: Ghost | null = null;
  if (opts.ghost) {
    const run = runGhost(opts.ghost.style, built.market, built.ticks);
    ghost = { ...opts.ghost, trades: run.trades, pnl: run.pnl };
  }
  const record: RoundRecord = {
    playerId,
    mode: opts.mode,
    pace: opts.pace,
    duelId: opts.duelId ?? null,
    roomCode: opts.roomCode ?? null,
    dailyDate: opts.dailyDate ?? null,
    seed,
    tickMs: opts.fast ? FAST_TICK_MS : TICK_MS,
    ticks: built.ticks,
    startTs: opts.startTs ?? createdAt + PRE_ROUND_MS,
    createdAt,
    trueSeries: built.trueSeries,
    market: built.market,
    botLog: built.botLog,
    reveal: built.reveal,
    cash: ROUND_CASH,
    pos: null,
    trades: [],
    settled: false,
    finalValue: null,
    pnl: null,
    ghost,
  };
  const [id] = await db.add(ROUNDS, [record]);
  if (!id) {
    throw new Error('Could not create a round');
  }
  return { id, record };
}

function equityOf(r: RoundRecord, tick: number): number {
  if (!r.pos) {
    return round2(r.cash);
  }
  return round2(r.cash + r.pos.margin + unrealized(r.pos, priceAt(r.market, tick)));
}

function publicRound(id: string, r: RoundRecord, now: number): Record<string, unknown> {
  const state = tickState(r, now);
  const tick = Math.max(0, state.tick);
  const base: Record<string, unknown> = {
    roundId: id,
    mode: r.mode,
    pace: r.pace,
    duelId: r.duelId,
    roomCode: r.roomCode,
    status: state.status,
    tickIndex: tick,
    tickMs: r.tickMs,
    startTs: r.startTs,
    totalTicks: r.ticks,
    serverNow: now,
    cash: round2(r.cash),
    roundCash: ROUND_CASH,
    pos: r.pos,
    trades: r.trades,
    bots: BOTS,
    leverages: LEVERAGES,
    ghostName: r.ghost ? r.ghost.name : null,
    ghostBlurb: r.ghost ? r.ghost.blurb : null,
  };
  if (state.status === 'ended') {
    base.prices = r.market.map(p => round2(p * 100));
    base.truePrices = r.trueSeries.map(p => round2(p * 100));
    base.botLog = r.botLog;
    base.reveal = r.reveal;
    base.finalValue = r.finalValue;
    base.pnl = r.pnl;
    base.ghost = r.ghost;
  } else if (state.status === 'live') {
    base.prices = r.market.slice(0, tick + 1).map(p => round2(p * 100));
    base.botLog = r.botLog.filter(a => a.t <= tick);
    if (r.ghost) {
      base.ghostAhead = r.ghost.pnl > equityOf(r, tick) - ROUND_CASH ? true : r.ghost.pnl < equityOf(r, tick) - ROUND_CASH ? false : null;
    }
  } else {
    base.prices = [];
    base.botLog = [];
  }
  return base;
}

// Apply any liquidation that happened between the last sync and `tick`. Persists if changed.
async function syncPosition(id: string, r: RoundRecord, tick: number): Promise<RoundRecord> {
  if (!r.pos) {
    return r;
  }
  const liqTick = liquidatedAt(r.pos, r.market, tick);
  if (liqTick === null) {
    return r;
  }
  const pos = r.pos;
  const trade: Trade = { side: pos.side, margin: pos.margin, lev: pos.lev, entryPrice: pos.entryPrice, exitPrice: pos.liqPrice, entryTick: pos.entryTick, exitTick: liqTick, pnl: -pos.margin, kind: 'liquidated' };
  const trades = [...r.trades, trade];
  const [ok] = await db.tx.update(ROUNDS, [{ id, record: { pos: null, trades }, if: { settled: false } }], { patch: true });
  if (ok) {
    await db.tx.update(PLAYERS, [{ id: r.playerId, record: { liquidations: increment(1) } }], { patch: true });
    return { ...r, pos: null, trades };
  }
  const fresh = await getRound(id);
  return fresh ?? r;
}

async function settleRound(id: string, r: RoundRecord): Promise<RoundRecord> {
  let cash = r.cash;
  const trades = [...r.trades];
  const lastTick = r.ticks - 1;
  if (r.pos) {
    const pos = r.pos;
    const liqTick = liquidatedAt(pos, r.market, lastTick);
    if (liqTick !== null) {
      trades.push({ side: pos.side, margin: pos.margin, lev: pos.lev, entryPrice: pos.entryPrice, exitPrice: pos.liqPrice, entryTick: pos.entryTick, exitTick: liqTick, pnl: -pos.margin, kind: 'liquidated' });
    } else {
      const exit = priceAt(r.market, lastTick);
      const pnl = unrealized(pos, exit);
      trades.push({ side: pos.side, margin: pos.margin, lev: pos.lev, entryPrice: pos.entryPrice, exitPrice: exit, entryTick: pos.entryTick, exitTick: lastTick, pnl, kind: 'settled' });
      cash = round2(cash + pos.margin + pnl);
    }
  }
  const finalValue = round2(cash);
  const pnl = round2(cash - ROUND_CASH);
  const [ok] = await db.tx.update(
    ROUNDS,
    [{ id, record: { settled: true, pos: null, trades, cash: finalValue, finalValue, pnl }, if: { settled: false } }],
    { patch: true }
  );
  if (!ok) {
    const fresh = await getRound(id);
    return fresh ?? r;
  }
  const player = await getPlayer(r.playerId);
  const patch: Record<string, unknown> = { roundsPlayed: increment(1), lifetimePnl: increment(pnl) };
  if (player && pnl > (player.bestRound ?? 0)) {
    patch.bestRound = pnl;
  }
  await db.tx.update(PLAYERS, [{ id: r.playerId, record: patch }], { patch: true });
  const updated: RoundRecord = { ...r, settled: true, pos: null, trades, cash: finalValue, finalValue, pnl };
  if (r.mode === 'daily' && r.dailyDate) {
    await finishDaily(id, updated);
  }
  if (r.mode === 'duel' && r.duelId) {
    await finishDuelRound(id, updated);
  }
  return updated;
}

async function finishDaily(roundId: string, r: RoundRecord): Promise<void> {
  const date = r.dailyDate as string;
  const player = await getPlayer(r.playerId);
  if (!player) {
    return;
  }
  const streak = player.lastDailyDate === prevDate(date) ? player.dailyStreak + 1 : 1;
  await db.tx.update(PLAYERS, [{ id: r.playerId, record: { dailyStreak: streak, lastDailyDate: date } }], { patch: true });
  await db.tx.update(DAILY_PLAYS, [{ id: date + '_' + r.playerId, record: { pnl: r.pnl, settled: true } }], { patch: true });
  await db.tx.add('board_' + date, [{ id: r.playerId, playerId: r.playerId, name: player.name, pnl: r.pnl, roundId, settledAt: Date.now() }]);
}

async function finishDuelRound(roundId: string, r: RoundRecord): Promise<void> {
  const duelId = r.duelId as string;
  const duel = await getDuel(duelId);
  if (!duel || !r.ghost || duel.status !== 'live' || duel.results.some(x => x.roundId === roundId)) {
    return;
  }
  const playerPnl = r.pnl ?? 0;
  const ghostPnl = r.ghost.pnl;
  const winner: DuelResult['winner'] = playerPnl > ghostPnl ? 'you' : playerPnl < ghostPnl ? 'ghost' : 'tie';
  const results = [...duel.results, { roundId, playerPnl, ghostPnl, winner }];
  const playerWins = duel.playerWins + (winner === 'you' ? 1 : 0);
  const ghostWins = duel.ghostWins + (winner === 'ghost' ? 1 : 0);
  const need = Math.ceil(BEST_OF / 2);
  let status: DuelRecord['status'] = 'live';
  let ratingDelta = 0;
  if (playerWins >= need) {
    status = 'won';
    ratingDelta = 25;
  } else if (ghostWins >= need) {
    status = 'lost';
    ratingDelta = -20;
  } else if (results.length >= MAX_DUEL_ROUNDS) {
    status = playerWins > ghostWins ? 'won' : playerWins < ghostWins ? 'lost' : 'draw';
    ratingDelta = status === 'won' ? 25 : status === 'lost' ? -20 : 0;
  }
  await db.tx.update(DUELS, [{ id: duelId, record: { results, playerWins, ghostWins, status, ratingDelta }, if: { status: 'live' } }], { patch: true });
  if (status !== 'live') {
    const patch: Record<string, unknown> = { rating: increment(ratingDelta) };
    if (status === 'won') {
      patch.duelsWon = increment(1);
    } else if (status === 'lost') {
      patch.duelsLost = increment(1);
    }
    await db.tx.update(PLAYERS, [{ id: r.playerId, record: patch }], { patch: true });
  }
}

async function loadRound(id: string, playerId: string): Promise<RoundRecord | { err: string; code: number }> {
  let r = await getRound(id);
  if (!r) {
    return { err: 'Round not found', code: 404 };
  }
  if (!playerId || r.playerId !== playerId) {
    return { err: 'This round belongs to another player', code: 403 };
  }
  const state = tickState(r, Date.now());
  if (state.status === 'ended') {
    if (!r.settled) {
      r = await settleRound(id, r);
    }
  } else if (state.status === 'live') {
    r = await syncPosition(id, r, state.tick);
  }
  return r;
}

function isErr(x: unknown): x is { err: string; code: number } {
  return typeof x === 'object' && x !== null && 'err' in x;
}

function publicDuel(id: string, d: DuelRecord): Record<string, unknown> {
  return {
    duelId: id,
    ghostName: d.ghostName,
    ghostStyle: d.ghostStyle,
    ghostBlurb: d.ghostBlurb,
    pace: d.pace,
    bestOf: BEST_OF,
    roundIds: d.roundIds,
    results: d.results,
    playerWins: d.playerWins,
    ghostWins: d.ghostWins,
    status: d.status,
    ratingDelta: d.ratingDelta,
    currentRoundId: d.roundIds.length ? d.roundIds[d.roundIds.length - 1] : null,
  };
}

// ---------- rooms ----------

async function roomView(room: RoomRecord, viewerId: string): Promise<Record<string, unknown>> {
  const now = Date.now();
  const standings: Array<{ id: string; name: string; equity: number | null; pnl: number | null; liquidated: boolean; trading: boolean }> = [];
  let viewerRoundId: string | null = room.roundIds[viewerId] ?? null;
  let allSettled = room.status === 'live';
  let anyLive = false;
  if (room.status !== 'lobby') {
    const ids = room.players.map(p => room.roundIds[p.id]).filter(Boolean);
    const rounds = ids.length ? await db.get<RoundRecord>(ROUNDS, ids, { consistent: true }) : [];
    for (let i = 0; i < room.players.length; i++) {
      const p = room.players[i];
      const rid = room.roundIds[p.id];
      let r = rounds[ids.indexOf(rid)] ?? null;
      if (!r) {
        standings.push({ id: p.id, name: p.name, equity: null, pnl: null, liquidated: false, trading: false });
        continue;
      }
      const st = tickState(r, now);
      if (p.bot && r.ghost) {
        if (st.status !== 'ended') {
          allSettled = false;
          if (st.status === 'live') {
            anyLive = true;
          }
        } else if (!r.settled) {
          await db.tx.update(ROUNDS, [{ id: rid, record: { settled: true, finalValue: round2(ROUND_CASH + r.ghost.pnl), pnl: r.ghost.pnl } }], { patch: true });
        }
        const btick = Math.max(0, st.tick);
        const beq = st.status === 'pending' ? ROUND_CASH : st.status === 'ended' ? ROUND_CASH + r.ghost.pnl : ghostEquityAt(r.ghost, r.market, btick);
        const openT = r.ghost.trades.find(t => t.entryTick <= btick && t.exitTick > btick);
        standings.push({ id: p.id, name: p.name, equity: round2(beq), pnl: round2(beq - ROUND_CASH), liquidated: r.ghost.trades.some(t => t.kind === 'liquidated' && t.exitTick <= btick) && !openT, trading: !!openT });
        continue;
      }
      if (st.status === 'ended') {
        if (!r.settled) {
          r = await settleRound(rid, r);
        }
      } else {
        allSettled = false;
        if (st.status === 'live') {
          anyLive = true;
          r = await syncPosition(rid, r, st.tick);
        }
      }
      const eq = st.status === 'pending' ? ROUND_CASH : equityOf(r, Math.max(0, st.tick));
      standings.push({
        id: p.id,
        name: p.name,
        equity: round2(eq),
        pnl: round2(eq - ROUND_CASH),
        liquidated: r.trades.some(t => t.kind === 'liquidated') && !r.pos,
        trading: !!r.pos,
      });
    }
    if (allSettled && room.status === 'live') {
      await finishRoom(room, standings);
      room = { ...room, status: 'ended' };
    }
  }
  const ended = room.status === 'ended';
  standings.sort((a, b) => (b.equity ?? 0) - (a.equity ?? 0));
  const me = standings.find(s => s.id === viewerId);
  const best = standings.length ? standings[0] : null;
  let ahead: boolean | null = null;
  if (me && standings.length > 1 && me.equity !== null) {
    const others = standings.filter(s => s.id !== viewerId && s.equity !== null).map(s => s.equity as number);
    const top = Math.max(...others);
    ahead = me.equity > top ? true : me.equity < top ? false : null;
  }
  return {
    code: room.code,
    hostId: room.hostId,
    pace: room.pace,
    isPublic: room.isPublic,
    status: room.status,
    players: room.players,
    startTs: room.startTs,
    ticks: room.ticks,
    serverNow: now,
    viewerRoundId,
    ahead,
    anyLive,
    standings: ended
      ? standings.map(s => ({ id: s.id, name: s.name, pnl: s.pnl, liquidated: s.liquidated }))
      : standings.map(s => ({ id: s.id, name: s.name, trading: s.trading, liquidated: s.liquidated })),
    winnerName: ended && best && standings.length > 1 && best.equity !== null && best.equity !== (standings[1].equity ?? null) ? best.name : null,
    maxPlayers: MAX_ROOM,
    nextCode: room.nextCode ?? null,
    humans: room.players.filter(p => !p.bot).length,
  };
}

async function finishRoom(room: RoomRecord, standings: Array<{ id: string; equity: number | null }>): Promise<void> {
  const [ok] = await db.tx.update(ROOMS, [{ id: room.code, record: { status: 'ended', resultsAwarded: true }, if: { status: 'live' } }], { patch: true });
  if (!ok) {
    return;
  }
  const sorted = [...standings].sort((a, b) => (b.equity ?? 0) - (a.equity ?? 0));
  if (sorted.length > 1 && sorted[0].equity !== null && sorted[0].equity !== sorted[1].equity && !sorted[0].id.startsWith('bot:')) {
    await db.tx.update(PLAYERS, [{ id: sorted[0].id, record: { liveWins: increment(1), rating: increment(15) } }], { patch: true });
  }
}

async function createRoom(host: { id: string; name: string }, pace: Pace, isPublic: boolean, fast: boolean, players?: RoomPlayer[]): Promise<RoomRecord> {
  for (let attempt = 0; attempt < 6; attempt++) {
    const code = makeCode();
    const record: RoomRecord = {
      code,
      hostId: host.id,
      pace,
      isPublic,
      players: players ?? [host],
      status: 'lobby',
      seed: null,
      ticks: null,
      startTs: null,
      tickMs: fast ? FAST_TICK_MS : TICK_MS,
      roundIds: {},
      createdAt: Date.now(),
      startedAt: null,
      resultsAwarded: false,
      nextCode: null,
    };
    const [id] = await db.tx.add(ROOMS, [{ id: code, ...record }]);
    if (id) {
      if (isPublic) {
        await db.tx.add(OPEN_ROOMS, [{ id: code, code, pace, createdAt: record.createdAt }]);
      }
      return record;
    }
  }
  throw new Error('Could not create a room');
}

async function joinRoom(code: string, player: { id: string; name: string }): Promise<RoomRecord | { err: string; code: number }> {
  for (let attempt = 0; attempt < 3; attempt++) {
    const room = await getRoom(code);
    if (!room) {
      return { err: 'No room with that code', code: 404 };
    }
    if (room.players.some(p => p.id === player.id)) {
      return room;
    }
    if (room.status !== 'lobby') {
      return { err: 'That round already started', code: 409 };
    }
    if (room.players.length >= MAX_ROOM) {
      return { err: 'Room is full', code: 409 };
    }
    const players = [...room.players, player];
    const [ok] = await db.tx.update(ROOMS, [{ id: code, record: { players }, if: { status: 'lobby' } }], { patch: true });
    if (ok) {
      return { ...room, players };
    }
  }
  return { err: 'Could not join. Try again.', code: 500 };
}

async function startRoom(room: RoomRecord): Promise<RoomRecord | { err: string; code: number }> {
  if (room.status !== 'lobby') {
    return room;
  }
  if (room.players.length < 2) {
    return { err: 'Need at least 2 players', code: 409 };
  }
  const seed = secureSeed();
  const rng = mulberry32(seed ^ 0x2545f491);
  const ticks = ticksFor(room.pace, rng);
  const startTs = Date.now() + PRE_ROUND_MS + 1000;
  const [ok] = await db.tx.update(ROOMS, [{ id: room.code, record: { status: 'live', seed, ticks, startTs, startedAt: Date.now() }, if: { status: 'lobby' } }], { patch: true });
  if (!ok) {
    const fresh = await getRoom(room.code);
    return fresh ?? room;
  }
  if (room.isPublic) {
    await db.tx.delete(OPEN_ROOMS, [room.code]);
  }
  const roundIds: Record<string, string> = {};
  for (const p of room.players) {
    const g = p.bot ? GHOSTS.find(x => x.style === p.bot) : undefined;
    const created = await createRound(p.id, { mode: 'live', pace: room.pace, fast: room.tickMs === FAST_TICK_MS, seed, ticks, startTs, roomCode: room.code, ghost: g });
    roundIds[p.id] = created.id;
  }
  await db.tx.update(ROOMS, [{ id: room.code, record: { roundIds } }], { patch: true });
  return { ...room, status: 'live', seed, ticks, startTs, roundIds };
}

// ---------- trade action ----------

interface TradeBody {
  playerId?: unknown;
  action?: unknown;
  side?: unknown;
  margin?: unknown;
  lev?: unknown;
  fraction?: unknown;
}

async function applyTrade(id: string, body: TradeBody): Promise<{ status: number; body: Record<string, unknown> }> {
  const playerId = asString(body.playerId);
  const action = asString(body.action);
  if (!playerId) {
    return { status: 400, body: { error: 'Missing player' } };
  }
  const loaded = await loadRound(id, playerId);
  if (isErr(loaded)) {
    return { status: loaded.code, body: { error: loaded.err } };
  }
  const r = loaded;
  const now = Date.now();
  const state = tickState(r, now);
  if (state.status === 'pending') {
    return { status: 409, body: { error: 'Hold on, the chart starts in a moment' } };
  }
  if (state.status === 'ended' || r.settled) {
    return { status: 409, body: { error: 'Round over' } };
  }
  const tick = state.tick;
  const price = priceAt(r.market, tick);
  let cash = r.cash;
  let pos = r.pos;
  const trades = [...r.trades];
  const expect = { settled: false, cash: r.cash };

  const closePart = (fraction: number, kind: Trade['kind']): void => {
    if (!pos) {
      return;
    }
    const f = clamp(fraction, 0.01, 1);
    const marginPart = f >= 1 ? pos.margin : round2(pos.margin * f);
    const qtyPart = f >= 1 ? pos.qty : round4(pos.qty * f);
    const partial: Position = { ...pos, margin: marginPart, qty: qtyPart };
    const pnl = unrealized(partial, price);
    trades.push({ side: pos.side, margin: marginPart, lev: pos.lev, entryPrice: pos.entryPrice, exitPrice: price, entryTick: pos.entryTick, exitTick: tick, pnl, kind });
    cash = round2(cash + marginPart + pnl);
    if (f >= 1) {
      pos = null;
    } else {
      pos = { ...pos, margin: round2(pos.margin - marginPart), qty: round4(pos.qty - qtyPart) };
    }
  };

  const openPos = (side: Side, margin: number, lev: number): string | null => {
    if (!Number.isFinite(margin) || margin < 1) {
      return 'Stake must be at least 1 credit';
    }
    if (!LEVERAGES.includes(lev)) {
      return 'Pick a leverage of ' + LEVERAGES.join(', ');
    }
    margin = round2(margin);
    if (margin > cash + 1e-9) {
      return 'Not enough credits. You have ' + round2(cash) + '.';
    }
    pos = { side, margin, lev, entryPrice: price, qty: round4((margin * lev) / price), entryTick: tick, liqPrice: liqPriceFor(side, price, lev) };
    cash = round2(cash - margin);
    return null;
  };

  if (action === 'open') {
    if (pos) {
      return { status: 409, body: { error: 'Close or flip your position first' } };
    }
    const side: Side = asString(body.side) === 'short' ? 'short' : 'long';
    const err = openPos(side, Number(body.margin), Number(body.lev));
    if (err) {
      return { status: 400, body: { error: err } };
    }
  } else if (action === 'add') {
    if (!pos) {
      return { status: 409, body: { error: 'No open position' } };
    }
    const add = round2(Number(body.margin));
    if (!Number.isFinite(add) || add < 1) {
      return { status: 400, body: { error: 'Add at least 1 credit' } };
    }
    if (add > cash + 1e-9) {
      return { status: 400, body: { error: 'Not enough credits. You have ' + round2(cash) + '.' } };
    }
    const addQty = (add * pos.lev) / price;
    const newQty = pos.qty + addQty;
    const entry = round2((pos.qty * pos.entryPrice + addQty * price) / newQty);
    pos = { ...pos, margin: round2(pos.margin + add), qty: round4(newQty), entryPrice: entry, liqPrice: liqPriceFor(pos.side, entry, pos.lev) };
    cash = round2(cash - add);
  } else if (action === 'close') {
    if (!pos) {
      return { status: 409, body: { error: 'No open position' } };
    }
    const f = Number(body.fraction);
    closePart(Number.isFinite(f) ? f : 1, 'close');
  } else if (action === 'flip') {
    if (!pos) {
      return { status: 409, body: { error: 'No open position' } };
    }
    const was = pos;
    closePart(1, 'close');
    const err = openPos(was.side === 'long' ? 'short' : 'long', Math.min(was.margin, cash), was.lev);
    if (err) {
      return { status: 400, body: { error: err } };
    }
  } else {
    return { status: 400, body: { error: 'Unknown action' } };
  }

  const [ok] = await db.tx.update(ROUNDS, [{ id, record: { pos, trades, cash }, if: expect }], { patch: true });
  if (!ok) {
    return { status: 409, body: { error: 'That changed under you. Try again.' } };
  }
  return { status: 200, body: { ok: true, pos, trades, cash, price, tickIndex: tick, serverNow: Date.now() } };
}

// ---------- routes ----------

export const handler = router({
  'GET /api/_healthcheck': [async () => json({ message: 'Success' })],

  'POST /api/players': [
    async () => {
      const record: PlayerRecord = {
        name: makeHandle(),
        rating: 1000,
        lifetimePnl: 0,
        roundsPlayed: 0,
        duelsWon: 0,
        duelsLost: 0,
        liveWins: 0,
        liquidations: 0,
        bestRound: 0,
        dailyStreak: 0,
        lastDailyDate: null,
        createdAt: Date.now(),
      };
      const [id] = await db.add(PLAYERS, [record]);
      if (!id) {
        return error('Could not create a player', 500);
      }
      return json(publicPlayer(id, record));
    },
  ],

  'GET /api/players/:id': [
    async ({ params }) => {
      const p = await getPlayer(params.id);
      if (!p) {
        return error('Player not found', 404);
      }
      return json(publicPlayer(params.id, p));
    },
  ],

  'PUT /api/players/:id': [
    async ({ params, body }) => {
      const b = (body ?? {}) as { name?: unknown };
      const name = asString(b.name).replace(/\s+/g, ' ').slice(0, 18);
      if (name.length < 2) {
        return error('Name must be at least 2 characters', 400);
      }
      const [ok] = await db.tx.update(PLAYERS, [{ id: params.id, record: { name } }], { patch: true });
      if (!ok) {
        return error('Player not found', 404);
      }
      const p = await getPlayer(params.id);
      return json(p ? publicPlayer(params.id, p) : { playerId: params.id, name });
    },
  ],

  // ----- daily -----

  'GET /api/daily': [
    async ({ query }) => {
      const playerId = asString(query.playerId);
      if (!playerId) {
        return error('Missing player', 400);
      }
      const now = Date.now();
      const date = utcDate(now);
      const [play] = await db.get<DailyPlay>(DAILY_PLAYS, [date + '_' + playerId], { consistent: true });
      const board = await db.list<{ playerId: string; name: string; pnl: number }>('board_' + date, { limit: 100 });
      const rows = board.items
        .map(x => ({ playerId: x.playerId, name: x.name, pnl: round2(x.pnl) }))
        .sort((a, b) => b.pnl - a.pnl)
        .slice(0, 25);
      const player = await getPlayer(playerId);
      return json({
        date,
        resetsAt: nextUtcMidnight(now),
        serverNow: now,
        played: !!play,
        roundId: play ? play.roundId : null,
        settled: play ? play.settled : false,
        pnl: play && play.settled ? play.pnl : null,
        streak: player ? player.dailyStreak : 0,
        board: rows,
        players: board.items.length,
      });
    },
  ],

  'POST /api/daily/start': [
    async ({ body }) => {
      const b = (body ?? {}) as { playerId?: unknown; speed?: unknown };
      const playerId = asString(b.playerId);
      if (!playerId) {
        return error('Missing player', 400);
      }
      const player = await getPlayer(playerId);
      if (!player) {
        return error('Player not found', 404);
      }
      const now = Date.now();
      const date = utcDate(now);
      const playId = date + '_' + playerId;
      const [existing] = await db.get<DailyPlay>(DAILY_PLAYS, [playId], { consistent: true });
      if (existing) {
        const r = await loadRound(existing.roundId, playerId);
        if (isErr(r)) {
          return error(r.err, r.code);
        }
        return json(publicRound(existing.roundId, r, Date.now()));
      }
      const seed = hashString(DAILY_SALT + ':' + date);
      const created = await createRound(playerId, { mode: 'daily', pace: 'standard', fast: fastFrom(b.speed), seed, dailyDate: date });
      const [added] = await db.tx.add(DAILY_PLAYS, [{ id: playId, playerId, date, roundId: created.id, pnl: null, settled: false }]);
      if (!added) {
        const [race] = await db.get<DailyPlay>(DAILY_PLAYS, [playId], { consistent: true });
        if (race) {
          const r = await loadRound(race.roundId, playerId);
          if (isErr(r)) {
            return error(r.err, r.code);
          }
          return json(publicRound(race.roundId, r, Date.now()));
        }
        return error('Could not start today\'s mystery. Try again.', 500);
      }
      return json(publicRound(created.id, created.record, Date.now()));
    },
  ],

  // ----- practice -----

  'POST /api/rounds': [
    async ({ body }) => {
      const b = (body ?? {}) as { playerId?: unknown; speed?: unknown; pace?: unknown };
      const playerId = asString(b.playerId);
      if (!playerId) {
        return error('Missing player', 400);
      }
      const player = await getPlayer(playerId);
      if (!player) {
        return error('Player not found', 404);
      }
      const created = await createRound(playerId, { mode: 'practice', pace: paceFrom(b.pace), fast: fastFrom(b.speed) });
      return json(publicRound(created.id, created.record, Date.now()));
    },
  ],

  'GET /api/rounds/:id': [
    async ({ params, query }) => {
      const r = await loadRound(params.id, asString(query.playerId));
      if (isErr(r)) {
        return error(r.err, r.code);
      }
      return json(publicRound(params.id, r, Date.now()));
    },
  ],

  'POST /api/rounds/:id/trade': [
    async ({ params, body }) => {
      const res = await applyTrade(params.id, (body ?? {}) as TradeBody);
      return json(res.body, res.status);
    },
  ],

  // ----- duels vs ghosts -----

  'POST /api/duels': [
    async ({ body }) => {
      const b = (body ?? {}) as { playerId?: unknown; speed?: unknown; pace?: unknown };
      const playerId = asString(b.playerId);
      if (!playerId) {
        return error('Missing player', 400);
      }
      const player = await getPlayer(playerId);
      if (!player) {
        return error('Player not found', 404);
      }
      const ghost = GHOSTS[Math.floor(Math.random() * GHOSTS.length)];
      const pace = paceFrom(b.pace);
      const duel: DuelRecord = {
        playerId,
        ghostName: ghost.name,
        ghostStyle: ghost.style,
        ghostBlurb: ghost.blurb,
        pace,
        roundIds: [],
        results: [],
        playerWins: 0,
        ghostWins: 0,
        status: 'live',
        ratingDelta: 0,
        createdAt: Date.now(),
      };
      const [duelId] = await db.add(DUELS, [duel]);
      if (!duelId) {
        return error('Could not start a duel', 500);
      }
      const created = await createRound(playerId, { mode: 'duel', pace, fast: fastFrom(b.speed), duelId, ghost });
      duel.roundIds = [created.id];
      await db.tx.update(DUELS, [{ id: duelId, record: { roundIds: duel.roundIds } }], { patch: true });
      return json({ duel: publicDuel(duelId, duel), round: publicRound(created.id, created.record, Date.now()) });
    },
  ],

  'GET /api/duels/:id': [
    async ({ params, query }) => {
      const playerId = asString(query.playerId);
      const duel = await getDuel(params.id);
      if (!duel) {
        return error('Duel not found', 404);
      }
      if (duel.playerId !== playerId) {
        return error('This duel belongs to another player', 403);
      }
      const currentId = duel.roundIds[duel.roundIds.length - 1];
      let round: Record<string, unknown> | null = null;
      if (currentId) {
        const r = await loadRound(currentId, playerId);
        if (!isErr(r)) {
          round = publicRound(currentId, r, Date.now());
        }
      }
      const fresh = (await getDuel(params.id)) ?? duel;
      return json({ duel: publicDuel(params.id, fresh), round });
    },
  ],

  'POST /api/duels/:id/next': [
    async ({ params, body }) => {
      const b = (body ?? {}) as { playerId?: unknown; speed?: unknown };
      const playerId = asString(b.playerId);
      const duel = await getDuel(params.id);
      if (!duel) {
        return error('Duel not found', 404);
      }
      if (duel.playerId !== playerId) {
        return error('This duel belongs to another player', 403);
      }
      const currentId = duel.roundIds[duel.roundIds.length - 1];
      if (currentId) {
        const r = await loadRound(currentId, playerId);
        if (isErr(r)) {
          return error(r.err, r.code);
        }
        if (!r.settled) {
          return error('Finish the current round first', 409);
        }
      }
      const fresh = (await getDuel(params.id)) ?? duel;
      if (fresh.status !== 'live') {
        return error('This duel is over', 409);
      }
      const created = await createRound(playerId, {
        mode: 'duel',
        pace: fresh.pace ?? 'standard',
        fast: fastFrom(b.speed),
        duelId: params.id,
        ghost: { name: fresh.ghostName, style: fresh.ghostStyle, blurb: fresh.ghostBlurb },
      });
      const roundIds = [...fresh.roundIds, created.id];
      await db.tx.update(DUELS, [{ id: params.id, record: { roundIds } }], { patch: true });
      return json({ duel: publicDuel(params.id, { ...fresh, roundIds }), round: publicRound(created.id, created.record, Date.now()) });
    },
  ],

  // ----- live rooms -----

  'POST /api/rooms': [
    async ({ body }) => {
      const b = (body ?? {}) as { playerId?: unknown; pace?: unknown; isPublic?: unknown; speed?: unknown };
      const playerId = asString(b.playerId);
      const player = playerId ? await getPlayer(playerId) : null;
      if (!player) {
        return error('Player not found', 404);
      }
      const room = await createRoom({ id: playerId, name: player.name }, paceFrom(b.pace), b.isPublic === true, fastFrom(b.speed));
      return json(await roomView(room, playerId));
    },
  ],

  'POST /api/rooms/quick': [
    async ({ body }) => {
      const b = (body ?? {}) as { playerId?: unknown; pace?: unknown; speed?: unknown };
      const playerId = asString(b.playerId);
      const player = playerId ? await getPlayer(playerId) : null;
      if (!player) {
        return error('Player not found', 404);
      }
      const pace = paceFrom(b.pace);
      const open = await db.list<{ code: string; pace: Pace; createdAt: number }>(OPEN_ROOMS, { limit: 25 });
      const cutoff = Date.now() - 10 * 60 * 1000;
      const candidates = open.items.filter(x => x.pace === pace && x.createdAt > cutoff).sort((a, b2) => a.createdAt - b2.createdAt);
      for (const c of candidates) {
        const joined = await joinRoom(c.code, { id: playerId, name: player.name });
        if (!isErr(joined)) {
          return json(await roomView(joined, playerId));
        }
        if (joined.code === 404 || joined.code === 409) {
          await db.tx.delete(OPEN_ROOMS, [c.code]);
        }
      }
      for (const stale of open.items.filter(x => x.createdAt <= cutoff)) {
        await db.tx.delete(OPEN_ROOMS, [stale.code]);
      }
      const room = await createRoom({ id: playerId, name: player.name }, pace, true, fastFrom(b.speed));
      return json(await roomView(room, playerId));
    },
  ],

  'POST /api/rooms/join': [
    async ({ body }) => {
      const b = (body ?? {}) as { playerId?: unknown; code?: unknown };
      const playerId = asString(b.playerId);
      const code = asString(b.code).toUpperCase();
      const player = playerId ? await getPlayer(playerId) : null;
      if (!player) {
        return error('Player not found', 404);
      }
      if (code.length !== 4) {
        return error('Room codes are 4 letters', 400);
      }
      const joined = await joinRoom(code, { id: playerId, name: player.name });
      if (isErr(joined)) {
        return error(joined.err, joined.code);
      }
      return json(await roomView(joined, playerId));
    },
  ],

  'GET /api/rooms/:code': [
    async ({ params, query }) => {
      const playerId = asString(query.playerId);
      const room = await getRoom(params.code.toUpperCase());
      if (!room) {
        return error('No room with that code', 404);
      }
      return json(await roomView(room, playerId));
    },
  ],

  'POST /api/rooms/:code/start': [
    async ({ params, body }) => {
      const b = (body ?? {}) as { playerId?: unknown };
      const playerId = asString(b.playerId);
      const room = await getRoom(params.code.toUpperCase());
      if (!room) {
        return error('No room with that code', 404);
      }
      if (!room.players.some(p => p.id === playerId)) {
        return error('You are not in this room', 403);
      }
      const started = await startRoom(room);
      if (isErr(started)) {
        return error(started.err, started.code);
      }
      return json(await roomView(started, playerId));
    },
  ],

  'POST /api/rooms/:code/fill': [
    async ({ params, body }) => {
      const b = (body ?? {}) as { playerId?: unknown };
      const playerId = asString(b.playerId);
      const room = await getRoom(params.code.toUpperCase());
      if (!room) {
        return error('No room with that code', 404);
      }
      if (!room.players.some(p => p.id === playerId)) {
        return error('You are not in this room', 403);
      }
      if (room.status !== 'lobby') {
        return json(await roomView(room, playerId));
      }
      const have = new Set(room.players.filter(p => p.bot).map(p => p.bot));
      const add = GHOSTS.filter(g => !have.has(g.style)).slice(0, Math.max(0, Math.min(3, MAX_ROOM - room.players.length)));
      const players = [...room.players, ...add.map(g => ({ id: 'bot:' + g.style, name: g.name, bot: g.style }))];
      await db.tx.update(ROOMS, [{ id: room.code, record: { players } }], { patch: true });
      const started = await startRoom({ ...room, players });
      if (isErr(started)) {
        return error(started.err, started.code);
      }
      return json(await roomView(started, playerId));
    },
  ],

  'POST /api/rooms/:code/rematch': [
    async ({ params, body }) => {
      const b = (body ?? {}) as { playerId?: unknown };
      const playerId = asString(b.playerId);
      const room = await getRoom(params.code.toUpperCase());
      if (!room) {
        return error('No room with that code', 404);
      }
      const me = room.players.find(p => p.id === playerId);
      if (!me) {
        return error('You are not in this room', 403);
      }
      if (room.nextCode) {
        const next = await getRoom(room.nextCode);
        if (next) {
          return json(await roomView(next, playerId));
        }
      }
      const next = await createRoom({ id: playerId, name: me.name }, room.pace, false, room.tickMs === FAST_TICK_MS, room.players);
      await db.tx.update(ROOMS, [{ id: room.code, record: { nextCode: next.code } }], { patch: true });
      return json(await roomView(next, playerId));
    },
  ],

  'POST /api/rounds/:id/skip': [
    async ({ params, body }) => {
      const b = (body ?? {}) as { playerId?: unknown };
      const playerId = asString(b.playerId);
      const loaded = await loadRound(params.id, playerId);
      if (isErr(loaded)) {
        return error(loaded.err, loaded.code);
      }
      if (loaded.mode === 'live' || loaded.mode === 'daily') {
        return error('You can only skip practice and duel rounds', 409);
      }
      if (loaded.pos || loaded.cash >= 1) {
        return error('You still have credits to trade', 409);
      }
      await db.tx.update(ROUNDS, [{ id: params.id, record: { endedEarly: true } }], { patch: true });
      const r = await loadRound(params.id, playerId);
      if (isErr(r)) {
        return error(r.err, r.code);
      }
      return json(publicRound(params.id, r, Date.now()));
    },
  ],

  'POST /api/rooms/:code/leave': [
    async ({ params, body }) => {
      const b = (body ?? {}) as { playerId?: unknown };
      const playerId = asString(b.playerId);
      const room = await getRoom(params.code.toUpperCase());
      if (!room) {
        return json({ ok: true });
      }
      if (room.status === 'lobby') {
        const players = room.players.filter(p => p.id !== playerId);
        if (players.filter(p => !p.bot).length === 0) {
          await db.tx.delete(ROOMS, [room.code]);
          await db.tx.delete(OPEN_ROOMS, [room.code]);
        } else {
          const hostId = room.hostId === playerId ? players[0].id : room.hostId;
          await db.tx.update(ROOMS, [{ id: room.code, record: { players, hostId } }], { patch: true });
        }
      }
      return json({ ok: true });
    },
  ],
});
