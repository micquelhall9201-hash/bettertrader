import type { IncomingMessage, ServerResponse } from 'node:http';
import { handler } from './_handler';

export default async function entry(req: IncomingMessage & { body?: unknown; query?: Record<string, string | string[]> }, res: ServerResponse): Promise<void> {
  const url = new URL(req.url ?? '/', 'http://x');
  const query: Record<string, string> = {};
  url.searchParams.forEach((v, k) => {
    query[k] = v;
  });
  let body: unknown = req.body ?? null;
  if (typeof body === 'string') {
    try {
      body = JSON.parse(body);
    } catch {
      body = null;
    }
  }
  const out = await handler({ method: (req.method ?? 'GET').toUpperCase(), path: url.pathname, query, body });
  res.statusCode = out.statusCode;
  for (const [k, v] of Object.entries(out.headers)) {
    res.setHeader(k, v);
  }
  res.setHeader('cache-control', 'no-store');
  res.end(out.body);
}
