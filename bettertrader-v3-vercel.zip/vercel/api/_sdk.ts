// Minimal server SDK for BetterTrader on Vercel + Neon Postgres.
// One table `kv(tbl text, id text, data jsonb)` holds every record.

import { neon } from '@neondatabase/serverless';
import { randomUUID } from 'node:crypto';

// ---------- router ----------

export interface RouterContext {
  body: unknown;
  query: Record<string, string>;
  params: Record<string, string>;
}

export interface RouterResponse {
  statusCode: number;
  headers: Record<string, string>;
  body: string;
}

type Middleware = (ctx: RouterContext) => Promise<RouterResponse | void> | RouterResponse | void;

export function json(data: unknown, status = 200): RouterResponse {
  return { statusCode: status, headers: { 'content-type': 'application/json' }, body: JSON.stringify(data) };
}

export function error(message: string, status = 400): RouterResponse {
  return json({ error: message }, status);
}

export interface RouterEvent {
  method: string;
  path: string;
  query: Record<string, string>;
  body: unknown;
}

export function router(routes: Record<string, Middleware[]>): (event: RouterEvent) => Promise<RouterResponse> {
  const compiled = Object.entries(routes).map(([key, chain]) => {
    const [method, pattern] = key.split(' ');
    const parts = pattern.split('/').filter(Boolean);
    return { method, parts, chain };
  });
  return async event => {
    const segs = event.path.split('?')[0].split('/').filter(Boolean);
    for (const r of compiled) {
      if (r.method !== event.method || r.parts.length !== segs.length) {
        continue;
      }
      const params: Record<string, string> = {};
      let ok = true;
      for (let i = 0; i < r.parts.length; i++) {
        if (r.parts[i].startsWith(':')) {
          params[r.parts[i].slice(1)] = decodeURIComponent(segs[i]);
        } else if (r.parts[i] !== segs[i]) {
          ok = false;
          break;
        }
      }
      if (!ok) {
        continue;
      }
      const ctx: RouterContext = { body: event.body, query: event.query, params };
      for (const mw of r.chain) {
        const res = await mw(ctx);
        if (res) {
          return res;
        }
      }
      return error('No response', 500);
    }
    return error('Not found', 404);
  };
}

// ---------- database ----------

const INC = Symbol('increment');
interface IncrementValue {
  [INC]: true;
  amount: number;
}

export function increment(amount: number): IncrementValue {
  return { [INC]: true, amount } as IncrementValue;
}

function isInc(v: unknown): v is IncrementValue {
  return typeof v === 'object' && v !== null && (v as Record<symbol, unknown>)[INC] === true;
}

type Row = { id: string; data: Record<string, unknown> };

type Query = (text: string, params: unknown[]) => Promise<Row[]>;
let q: Query | null = null;
let ready: Promise<void> | null = null;

async function getQuery(): Promise<Query> {
  if (q) {
    return q;
  }
  const url = process.env.DATABASE_URL ?? process.env.POSTGRES_URL ?? process.env.NEON_DATABASE_URL;
  if (!url) {
    throw new Error('DATABASE_URL is not set. Add the Neon integration in Vercel.');
  }
  if (/neon\.tech/.test(url)) {
    const client = neon(url);
    q = async (text, params) => (await client.query(text, params)) as unknown as Row[];
  } else {
    const { default: pg } = await import('pg');
    const pool = new pg.Pool({ connectionString: url });
    q = async (text, params) => (await pool.query(text, params)).rows as Row[];
  }
  return q;
}

async function ensure(): Promise<Query> {
  const run = await getQuery();
  if (!ready) {
    ready = run('CREATE TABLE IF NOT EXISTS kv (tbl text NOT NULL, id text NOT NULL, data jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY (tbl, id))', []).then(() => undefined);
  }
  await ready;
  return run;
}

function splitPatch(record: Record<string, unknown>): { plain: Record<string, unknown>; incs: Array<[string, number]> } {
  const plain: Record<string, unknown> = {};
  const incs: Array<[string, number]> = [];
  for (const [k, v] of Object.entries(record)) {
    if (isInc(v)) {
      incs.push([k, v.amount]);
    } else if (v !== undefined) {
      plain[k] = v;
    }
  }
  return { plain, incs };
}

async function updateOne(table: string, id: string, record: Record<string, unknown>, cond: Record<string, unknown> | undefined, patch: boolean): Promise<boolean> {
  const run = await ensure();
  const { plain, incs } = splitPatch(record);
  const condJson = JSON.stringify(cond ?? {});
  if (!patch) {
    const rows = await run('UPDATE kv SET data = $1::jsonb WHERE tbl = $2 AND id = $3 AND data @> $4::jsonb RETURNING id', [JSON.stringify(plain), table, id, condJson]);
    if (rows.length) {
      return true;
    }
    if (cond && Object.keys(cond).length) {
      return false;
    }
    const ins = await run('INSERT INTO kv (tbl, id, data) VALUES ($1, $2, $3::jsonb) ON CONFLICT DO NOTHING RETURNING id', [table, id, JSON.stringify(plain)]);
    return ins.length > 0;
  }
  // Build increments as a chain of jsonb_set; do it in JS-side SQL text with parameters.
  let expr = 'data || $1::jsonb';
  const params: unknown[] = [JSON.stringify(plain)];
  for (const [k, amt] of incs) {
    params.push(k, amt);
    const kIdx = params.length - 1;
    const aIdx = params.length;
    expr = `jsonb_set(${expr}, ARRAY[$${kIdx}::text], to_jsonb(COALESCE(((${expr})->>$${kIdx})::numeric, 0) + $${aIdx}::numeric))`;
  }
  params.push(table, id, condJson);
  const n = params.length;
  const text = `UPDATE kv SET data = ${expr} WHERE tbl = $${n - 2} AND id = $${n - 1} AND data @> $${n}::jsonb RETURNING id`;
  const rows = await run(text, params);
  return rows.length > 0;
}

export const db = {
  async add(table: string, records: ReadonlyArray<object>): Promise<Array<string | null>> {
    const run = await ensure();
    const out: Array<string | null> = [];
    for (const r of records as Array<Record<string, unknown>>) {
      const { id: chosen, ...rest } = r as { id?: unknown } & Record<string, unknown>;
      const id = typeof chosen === 'string' && chosen ? chosen : randomUUID();
      const rows = await run('INSERT INTO kv (tbl, id, data) VALUES ($1, $2, $3::jsonb) ON CONFLICT DO NOTHING RETURNING id', [table, id, JSON.stringify(rest)]);
      out.push(rows.length ? id : null);
    }
    return out;
  },
  async get<T = Record<string, unknown>>(table: string, ids: string[], _opts?: { consistent?: boolean }): Promise<Array<T | null>> {
    const run = await ensure();
    if (!ids.length) {
      return [];
    }
    const rows = await run('SELECT id, data FROM kv WHERE tbl = $1 AND id = ANY($2::text[])', [table, ids]);
    const map = new Map(rows.map(r => [r.id, r.data]));
    return ids.map(id => (map.get(id) as T | undefined) ?? null);
  },
  async list<T = Record<string, unknown>>(table: string, opts?: { limit?: number }): Promise<{ items: Array<Omit<T, 'id'> & { id: string }> }> {
    const run = await ensure();
    const limit = Math.min(500, opts?.limit ?? 50);
    const rows = await run('SELECT id, data FROM kv WHERE tbl = $1 ORDER BY created_at ASC LIMIT $2', [table, limit]);
    return { items: rows.map(r => ({ ...(r.data as Omit<T, 'id'>), id: r.id })) };
  },
  async update(table: string, items: Array<{ id: string; record: Record<string, unknown> }>): Promise<boolean[]> {
    const out: boolean[] = [];
    for (const it of items) {
      out.push(await updateOne(table, it.id, it.record, undefined, false));
    }
    return out;
  },
  async delete(table: string, ids: string[]): Promise<boolean[]> {
    const run = await ensure();
    const out: boolean[] = [];
    for (const id of ids) {
      const rows = await run('DELETE FROM kv WHERE tbl = $1 AND id = $2 RETURNING id', [table, id]);
      out.push(rows.length > 0);
    }
    return out;
  },
  tx: {
    add(table: string, records: ReadonlyArray<object>): Promise<Array<string | null>> {
      return db.add(table, records);
    },
    async update(table: string, items: Array<{ id: string; record: Record<string, unknown>; if?: Record<string, unknown> }>, opts?: { patch?: boolean }): Promise<boolean[]> {
      const out: boolean[] = [];
      for (const it of items) {
        out.push(await updateOne(table, it.id, it.record, it.if, !!opts?.patch));
      }
      return out;
    },
    delete(table: string, ids: string[]): Promise<boolean[]> {
      return db.delete(table, ids);
    },
  },
};
